

## Plan: Add Quote & Workflow screenshots to your CSP Quote Generator deck

I parsed your `CSP_Quote_Generator.pptx`. Speaker notes were not exposed by the parser, but based on slide titles/content, two slides are the natural fit for product imagery:

### Slides that need images

| # | Slide | Image to insert | Why |
|---|---|---|---|
| **3** | "What Has Been Built (Capabilities)" | **Customer-facing Quote screenshot** (the branded PDF-ready output) | Bullet 3 explicitly says "Branded print / PDF-ready quote output" — showing the actual artifact lands the message. |
| **5** | "Pilot Approach & Current View" | **Workflow screenshot** (Quote creation / editor flow — header form + line items + Save) | The slide is literally titled "Current View" and talks about real quote scenarios + UX validation. |

I'll leave Slides 1, 2, 4 (icons), and 6 (icons) untouched.

### How I'll capture the screenshots

I'll log into the live preview (`/login` → quotes) and capture two clean shots:

1. **Quote output shot** — open an existing quote → "View Quote" → screenshot the branded customer view (DBiz.ai header, grouped NCE table, grand total).
2. **Workflow shot** — open "New Quote" or "Edit Quote" → screenshot the editor showing the header form + a couple of line items so the calculation columns (Term, Frequency, Margin) are visible.

Both will be cropped tightly, framed with a subtle macOS-style window/shadow for polish (consistent with a managerial deck), and embedded at high resolution so they're sharp on a projector.

### How I'll edit the deck

- Unpack the .pptx → on slide 3, resize the right-side capability list to make room and place the **Quote screenshot** to its right (or replace the decorative right column entirely with the screenshot + small caption "Sample generated quote").
- On slide 5, place the **Workflow screenshot** below or beside the three coloured bullets with caption "Quote creation workflow".
- Preserve existing fonts, colours, title bar, and the orange/green/blue accent bars — only add image + caption.
- Repack and run visual QA: convert every slide to JPG and inspect for overlap, clipping, and alignment before delivering.

### Deliverable

`/mnt/documents/CSP_Quote_Generator_v2.pptx` — original preserved, ready to present.

### One quick check before I proceed

Two small choices — pick what you'd like; otherwise I'll go with the defaults marked ★:

- **Quote sample data**: ★ use any existing saved quote from your account / OR I create a representative demo quote (AUD/Commercial, 2–3 Microsoft 365 + Dynamics products) just for the screenshot.
- **Slide 5 image**: ★ Quote **editor** view (header form + line items) / OR a **two-shot composite** showing editor → final quote side-by-side to literally illustrate "workflow".

Reply with your picks (or "go with defaults") and I'll build it.

