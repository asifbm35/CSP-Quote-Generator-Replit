import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { AppHeader } from '@/components/AppHeader';
import { Button } from '@/components/ui/button';
import { Plus, FileText, Trash2 } from 'lucide-react';
import { formatCurrency, type Currency } from '@/lib/pricing';

export const Route = createFileRoute('/')({
  component: Index,
  head: () => ({
    meta: [
      { title: 'CSP Quote Generator — DBiz.ai' },
      { name: 'description', content: 'Generate Microsoft CSP license quotes with correct NCE rules and margin-driven pricing.' },
    ],
  }),
});

function Index() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!user) {
    navigate({ to: '/login' });
    return null;
  }

  return <QuoteListPage />;
}

function QuoteListPage() {
  const [quotes, setQuotes] = useState<any[]>([]);
  const [loadingQuotes, setLoadingQuotes] = useState(true);

  const fetchQuotes = async () => {
    setLoadingQuotes(true);
    const { data } = await supabase
      .from('quotes')
      .select('*')
      .order('created_at', { ascending: false });
    setQuotes(data || []);
    setLoadingQuotes(false);
  };

  useEffect(() => { fetchQuotes(); }, []);

  const deleteQuote = async (id: string) => {
    if (!confirm('Delete this quote?')) return;
    await supabase.from('quotes').delete().eq('id', id);
    fetchQuotes();
  };

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Your Quotes</h1>
            <p className="text-sm text-muted-foreground">Create and manage Microsoft CSP license quotes</p>
          </div>
          <Button asChild>
            <Link to="/quotes/new">
              <Plus className="h-4 w-4" /> New Quote
            </Link>
          </Button>
        </div>

        {loadingQuotes ? (
          <div className="flex justify-center py-12">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : quotes.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border p-12 text-center">
            <FileText className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
            <p className="text-lg font-medium text-foreground">No quotes yet</p>
            <p className="text-sm text-muted-foreground">Create your first CSP quote to get started.</p>
            <Button asChild className="mt-4">
              <Link to="/quotes/new"><Plus className="h-4 w-4" /> Create Quote</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {quotes.map(q => (
              <div key={q.id} className="flex items-center justify-between rounded-lg border border-border bg-card p-4 transition-colors hover:bg-accent/30">
                <Link to="/quotes/$quoteId" params={{ quoteId: q.id }} className="flex-1">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                      <FileText className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{q.customer_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {q.currency} • {q.customer_segment} • Valid till {q.valid_till} • {q.status}
                      </p>
                    </div>
                  </div>
                </Link>
                <Button variant="ghost" size="icon" onClick={() => deleteQuote(q.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
