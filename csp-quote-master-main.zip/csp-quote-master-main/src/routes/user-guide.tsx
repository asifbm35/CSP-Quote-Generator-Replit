import { createFileRoute } from '@tanstack/react-router';
import { AppHeader } from '@/components/AppHeader';
import { Button } from '@/components/ui/button';
import {
  BookOpen,
  Printer,
  LogIn,
  Database,
  FilePlus,
  Edit3,
  FileText,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';

export const Route = createFileRoute('/user-guide')({
  component: UserGuidePage,
  head: () => ({
    meta: [
      { title: 'User Guide — DBiz.ai CSP Quote Generator' },
      { name: 'description', content: 'Step-by-step guide for the DBiz.ai CSP Quote Generator: uploading price lists, creating quotes, editing versions, and exporting customer quotes.' },
    ],
  }),
});

function SectionCard({
  id,
  icon: Icon,
  title,
  children,
}: {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-20 rounded-xl border border-border bg-card shadow-sm print:break-inside-avoid">
      <div className="flex items-center gap-3 rounded-t-xl bg-primary px-5 py-3 text-primary-foreground">
        <Icon className="h-5 w-5" />
        <h2 className="text-base font-semibold">{title}</h2>
      </div>
      <div className="space-y-3 px-5 py-5 text-sm leading-relaxed text-foreground">{children}</div>
    </section>
  );
}

function Callout({
  variant = 'info',
  title,
  children,
}: {
  variant?: 'info' | 'warning' | 'success';
  title: string;
  children: React.ReactNode;
}) {
  const styles = {
    info: { wrap: 'border-primary/30 bg-primary/5', icon: 'text-primary', Icon: Lightbulb },
    warning: { wrap: 'border-amber-300 bg-amber-50', icon: 'text-amber-600', Icon: AlertTriangle },
    success: { wrap: 'border-emerald-300 bg-emerald-50', icon: 'text-emerald-600', Icon: CheckCircle2 },
  }[variant];
  const I = styles.Icon;
  return (
    <div className={`flex gap-3 rounded-lg border p-3 ${styles.wrap}`}>
      <I className={`h-5 w-5 flex-shrink-0 ${styles.icon}`} />
      <div className="text-sm">
        <p className="mb-1 font-semibold text-foreground">{title}</p>
        <div className="text-muted-foreground">{children}</div>
      </div>
    </div>
  );
}

function VisualPlaceholder({ label, description }: { label: string; description: string }) {
  return (
    <div className="my-3 rounded-lg border-2 border-dashed border-primary/30 bg-primary/5 px-4 py-6 text-center">
      <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-primary">Screen Preview</div>
      <div className="text-sm font-medium text-foreground">{label}</div>
      <div className="mt-1 text-xs text-muted-foreground">{description}</div>
    </div>
  );
}

function UserGuidePage() {
  const sections = [
    { id: 'intro', label: '1. Introduction' },
    { id: 'login', label: '2. Login & Account Access' },
    { id: 'before', label: '3. Before Creating a Quote' },
    { id: 'price-lists', label: '4. Uploading a Partner Price List' },
    { id: 'new-quote', label: '5. Creating a New Quote' },
    { id: 'edit-quote', label: '6. Editing an Existing Quote' },
    { id: 'understanding', label: '7. Understanding the Saved Quote' },
    { id: 'print', label: '8. Printing / PDF' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="print:hidden">
        <AppHeader />
      </div>

      <main className="mx-auto max-w-5xl px-4 py-8 print:px-0 print:py-0">
        {/* Hero */}
        <div className="mb-8 overflow-hidden rounded-xl shadow-lg print:shadow-none">
          <div
            className="relative px-8 py-10 text-primary-foreground"
            style={{
              background:
                'linear-gradient(135deg, oklch(0.32 0.14 255) 0%, oklch(0.45 0.18 255) 55%, oklch(0.55 0.16 255) 100%)',
            }}
          >
            <div className="flex items-center gap-3">
              <BookOpen className="h-7 w-7" />
              <span className="text-xs font-semibold uppercase tracking-widest text-primary-foreground/80">
                DBiz.ai Internal Documentation
              </span>
            </div>
            <h1 className="mt-3 text-3xl font-bold">CSP Quote Generator — User Guide</h1>
            <p className="mt-2 max-w-2xl text-sm text-primary-foreground/90">
              A step-by-step reference for the quote generation team. Learn how to upload partner
              price lists, build accurate Microsoft CSP quotes, and share them with customers — all
              in a fraction of the time it took with Excel.
            </p>
            <div className="mt-5 flex flex-wrap gap-2 print:hidden">
              <Button variant="secondary" size="sm" onClick={() => window.print()}>
                <Printer className="h-4 w-4" /> Print / Save as PDF
              </Button>
            </div>
          </div>
        </div>

        {/* Table of contents */}
        <div className="mb-8 rounded-xl border border-border bg-card p-5 print:hidden">
          <h2 className="mb-3 text-sm font-semibold text-foreground">On this page</h2>
          <ol className="grid gap-1.5 sm:grid-cols-2">
            {sections.map((s) => (
              <li key={s.id}>
                <a href={`#${s.id}`} className="text-sm text-primary hover:underline">
                  {s.label}
                </a>
              </li>
            ))}
          </ol>
        </div>

        <div className="space-y-6">
          {/* A. Introduction */}
          <SectionCard id="intro" icon={Sparkles} title="1. Introduction">
            <p>
              The <strong>CSP Quote Generator</strong> is an internal DBiz.ai tool designed to
              simplify and standardize the process of creating Microsoft Cloud Solution Provider
              (CSP) license quotes for our customers.
            </p>
            <p>
              For years, the quote generation team relied on manual Excel sheets — copying partner
              price data, recalculating margins, formatting customer-facing documents, and
              double-checking NCE commitment rules. This was slow, repetitive, and prone to small
              errors that caused friction with customers and internal finance reviews.
            </p>
            <p>This app replaces that manual process with a guided, automated workflow.</p>
            <Callout variant="success" title="Key benefits for the quote team">
              <ul className="ml-4 list-disc space-y-1">
                <li>One source of truth — partner price lists are uploaded once and reused.</li>
                <li>Margin-driven pricing — set the profit margin, the customer price is calculated for you.</li>
                <li>NCE rules built in — the app blocks invalid commitment / billing combinations.</li>
                <li>Branded, consistent customer quotes — ready to share or print as PDF.</li>
                <li>Internal margin view stays internal — customers never see partner cost or margin.</li>
              </ul>
            </Callout>
          </SectionCard>

          {/* B. Login */}
          <SectionCard id="login" icon={LogIn} title="2. Login & Account Access">
            <p>
              The app is restricted to internal DBiz.ai users. You will need an account before you
              can access any feature.
            </p>
            <h3 className="mt-2 font-semibold text-foreground">Signing up</h3>
            <ol className="ml-4 list-decimal space-y-1">
              <li>Open the app — you will land on the Sign In screen.</li>
              <li>Click <strong>"Sign Up"</strong> below the form.</li>
              <li>Enter your work email and a password (minimum 6 characters).</li>
              <li>Click <strong>"Create Account"</strong>.</li>
              <li>You'll see a confirmation message: check your inbox for a verification email.</li>
              <li>Click the link in the email to confirm your address.</li>
            </ol>
            <h3 className="mt-3 font-semibold text-foreground">Signing in</h3>
            <ol className="ml-4 list-decimal space-y-1">
              <li>Return to the Sign In screen.</li>
              <li>Enter your verified email and password.</li>
              <li>Click <strong>"Sign In"</strong> — you'll be taken to the Quotes home page.</li>
            </ol>
            <VisualPlaceholder label="Sign In page" description="DBiz.ai logo on top, email & password fields, Sign In / Sign Up toggle." />
            <Callout variant="info" title="Tip">
              Your session stays active across browser tabs. Use the <strong>Sign Out</strong>{' '}
              button in the top-right corner when you're done.
            </Callout>
          </SectionCard>

          {/* C. Before */}
          <SectionCard id="before" icon={Lightbulb} title="3. Before Creating a Quote">
            <p>
              Every quote in the app is priced from a <strong>Partner Price List</strong>. Before
              you start a new quote, make sure the right price list already exists in the system
              for the customer's region, market, currency, and the month you want to quote from.
            </p>
            <p>If the price list is missing, the app will not be able to look up partner cost or ERP price for the products.</p>
            <Callout variant="warning" title="Always check first">
              Confirm with finance / partner ops which Microsoft Partner Center price list month
              should be used for this customer. Using the wrong month leads to incorrect customer
              pricing.
            </Callout>
          </SectionCard>

          {/* D. Upload */}
          <SectionCard id="price-lists" icon={Database} title="4. Uploading a Partner Price List">
            <ol className="ml-4 list-decimal space-y-2">
              <li>
                Click <strong>"Price Lists"</strong> in the top navigation bar.
              </li>
              <li>
                Click <strong>"Upload Price List"</strong>.
              </li>
              <li>
                Select the Microsoft Partner Center CSV file from your computer.
              </li>
              <li>
                Choose the matching <strong>Region</strong>, <strong>Market</strong>,{' '}
                <strong>Currency</strong>, and <strong>Price List Month</strong>.
              </li>
              <li>
                Give the price list a friendly name (e.g. "India INR — Mar 2026").
              </li>
              <li>
                Click <strong>Upload</strong>. The app will read the CSV, map Microsoft's standard
                headers automatically, and confirm how many rows were imported.
              </li>
            </ol>
            <VisualPlaceholder label="Price Lists upload modal" description="File picker, region/market/currency dropdowns, month selector, validation summary." />
            <Callout variant="success" title="Automatic header mapping">
              The app understands Microsoft's standard CSV column names (Product Title, ERP Price,
              Partner Price, Commitment Term, Billing Plan, Customer Segment, etc.). You don't
              need to rename or rearrange any columns.
            </Callout>
            <Callout variant="warning" title="If something looks off">
              If the row count seems too low, the wrong file or wrong currency may have been
              picked. Re-upload with the correct file — duplicate uploads do not corrupt existing
              quotes.
            </Callout>
          </SectionCard>

          {/* E. New quote */}
          <SectionCard id="new-quote" icon={FilePlus} title="5. Creating a New Quote">
            <ol className="ml-4 list-decimal space-y-2">
              <li>
                On the Quotes home page, click <strong>"New Quote"</strong>.
              </li>
              <li>
                Choose the <strong>Region</strong>, <strong>Market / Currency</strong>, and{' '}
                <strong>Price List Month</strong>. The app will load the matching partner price
                list. Once products are added, these fields lock so the quote stays consistent.
              </li>
              <li>
                Enter the <strong>Customer Name</strong>, <strong>Customer Segment</strong>, and{' '}
                <strong>Quote Valid Till</strong> date.
              </li>
              <li>
                Choose a <strong>Margin Strategy</strong>:
                <ul className="ml-5 mt-1 list-disc space-y-0.5 text-muted-foreground">
                  <li><strong>Uniform</strong> — same target margin for all products.</li>
                  <li><strong>Per-product</strong> — set the margin individually on each line.</li>
                </ul>
              </li>
              <li>
                Add products one by one:
                <ul className="ml-5 mt-1 list-disc space-y-0.5 text-muted-foreground">
                  <li>Pick the <strong>Product</strong> from the dropdown.</li>
                  <li>Set <strong>Quantity</strong>.</li>
                  <li>Choose <strong>Commitment Term</strong> (Monthly / Annual / Triennial).</li>
                  <li>Choose <strong>Billing Frequency</strong> (Monthly / Annual / Triennial).</li>
                  <li>If using per-product margin, set the <strong>Target Margin %</strong>.</li>
                </ul>
              </li>
              <li>Review the calculated customer price for each line. Invalid NCE combinations are flagged inline.</li>
              <li>
                When everything looks good, click <strong>"Save Quote"</strong>.
              </li>
            </ol>
            <VisualPlaceholder label="New Quote editor" description="Quote header on top, products table with inline pricing, Save Quote action at the bottom." />
            <Callout variant="info" title="Profit margin drives the price">
              You set the <strong>profit margin</strong>; the app calculates the customer price and
              the equivalent discount. You don't need to enter a discount manually.
            </Callout>
            <Callout variant="warning" title="Loss-making quotes are blocked">
              If the calculated customer price ever drops below partner cost, the app will not
              allow you to save the quote. Increase the margin to fix it.
            </Callout>
          </SectionCard>

          {/* F. Edit */}
          <SectionCard id="edit-quote" icon={Edit3} title="6. Editing an Existing Quote">
            <ol className="ml-4 list-decimal space-y-2">
              <li>
                Open the Quotes home page and click on a saved quote to view it.
              </li>
              <li>
                Click the <strong>"Edit"</strong> button at the top of the quote.
              </li>
              <li>
                The full quote opens in the editor, pre-filled with all customer details, products,
                commitments, billing, and margins.
              </li>
              <li>Make any changes you need — change quantities, adjust margins, add or remove products.</li>
              <li>
                Click <strong>"Save as New Version"</strong>.
              </li>
            </ol>
            <Callout variant="success" title="Versioning is automatic">
              Saving an edited quote always creates a <strong>new version</strong>. The original
              saved quote is left untouched, so you keep a full history of what was sent to the
              customer at each point in time.
            </Callout>
          </SectionCard>

          {/* G. Understanding */}
          <SectionCard id="understanding" icon={FileText} title="7. Understanding the Saved Quote">
            <p>Every saved quote has two views, accessible via tabs at the top:</p>
            <h3 className="mt-2 font-semibold text-foreground">Customer Quote tab</h3>
            <ul className="ml-4 list-disc space-y-1">
              <li>This is the <strong>customer-facing</strong> view — clean, branded, ready to share.</li>
              <li>
                Products are grouped into sections by <strong>Commitment Term</strong> and{' '}
                <strong>Billing Frequency</strong>, e.g. "NCE Commitment Type — Annual Commitment
                (Monthly Billing)".
              </li>
              <li>Each line shows product, quantity, unit price, and total in the customer's currency.</li>
              <li>Partner cost, margin, and discount are <strong>never</strong> shown here.</li>
            </ul>
            <h3 className="mt-3 font-semibold text-foreground">Internal Margins tab</h3>
            <ul className="ml-4 list-disc space-y-1">
              <li>This view is for internal use only and is never shared with customers.</li>
              <li>Products are grouped the same way as the Customer Quote, for easy comparison.</li>
              <li>
                For each line you can see:
                <ul className="ml-5 mt-1 list-disc space-y-0.5 text-muted-foreground">
                  <li><strong>ERP</strong> — Microsoft's published list price.</li>
                  <li><strong>Partner Cost</strong> — what DBiz.ai pays Microsoft.</li>
                  <li><strong>Margin</strong> — the profit margin applied on the partner cost.</li>
                  <li><strong>Discount</strong> — the equivalent discount the customer is getting off the ERP price.</li>
                </ul>
              </li>
            </ul>
            <VisualPlaceholder label="Saved quote with Customer & Internal tabs" description="Branded hero header, blue section banners by commitment type, totals on the right." />
          </SectionCard>

          {/* H. Print */}
          <SectionCard id="print" icon={Printer} title="8. Printing / PDF">
            <ol className="ml-4 list-decimal space-y-2">
              <li>Open the saved quote and stay on the <strong>Customer Quote</strong> tab.</li>
              <li>Use your browser's <strong>Print</strong> option (Ctrl/Cmd + P).</li>
              <li>Choose <strong>"Save as PDF"</strong> as the destination.</li>
              <li>Save the file and share it directly with the customer.</li>
            </ol>
            <Callout variant="info" title="Customer-ready format">
              The customer quote is already styled with DBiz.ai branding, the right currency
              symbol, and clean section grouping — no extra formatting in Word or Excel needed.
            </Callout>
          </SectionCard>

          {/* Footer */}
          <div className="rounded-xl border border-border bg-muted/40 p-5 text-center text-xs text-muted-foreground print:hidden">
            Need help that isn't covered here? Reach out to the internal DBiz.ai CSP operations team.
          </div>
        </div>
      </main>
    </div>
  );
}
