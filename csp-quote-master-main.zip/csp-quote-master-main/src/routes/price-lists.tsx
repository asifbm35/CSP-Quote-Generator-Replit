import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { AppHeader } from '@/components/AppHeader';
import { Button } from '@/components/ui/button';
import { PriceListUploadModal } from '@/components/PriceListUploadModal';
import { Plus, Database, Trash2, Upload } from 'lucide-react';

export const Route = createFileRoute('/price-lists')({
  component: PriceListsPage,
  head: () => ({
    meta: [
      { title: 'Partner Price Lists — DBiz.ai' },
      { name: 'description', content: 'Manage Microsoft CSP partner price lists by region and month.' },
    ],
  }),
});

function PriceListsPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [lists, setLists] = useState<any[]>([]);
  const [fetching, setFetching] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);

  const fetchLists = async () => {
    setFetching(true);
    const { data } = await supabase
      .from('partner_price_lists')
      .select('*')
      .order('uploaded_at', { ascending: false });
    setLists(data || []);
    setFetching(false);
  };

  useEffect(() => { if (user) fetchLists(); }, [user]);

  if (loading) return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  if (!user) { navigate({ to: '/login' }); return null; }

  const deleteList = async (id: string, name: string) => {
    if (!confirm(`Delete price list "${name}"? Saved quotes will keep their snapshot prices, but will lose their link to this list.`)) return;
    await supabase.from('partner_price_lists').delete().eq('id', id);
    fetchLists();
  };

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Partner Price Lists</h1>
            <p className="text-sm text-muted-foreground">Upload monthly price lists per region and currency.</p>
          </div>
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="h-4 w-4" /> Upload Price List
          </Button>
        </div>

        {fetching ? (
          <div className="flex justify-center py-12">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : lists.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border p-12 text-center">
            <Database className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
            <p className="text-lg font-medium text-foreground">No price lists yet</p>
            <p className="text-sm text-muted-foreground">Upload your first Partner Price List CSV to start quoting.</p>
            <Button className="mt-4" onClick={() => setModalOpen(true)}>
              <Upload className="h-4 w-4" /> Upload CSV
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {lists.map(l => (
              <div key={l.id} className="flex items-center justify-between rounded-lg border border-border bg-card p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                    <Database className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{l.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {l.region} • {l.row_count} rows • Uploaded {new Date(l.uploaded_at).toLocaleDateString()}
                      {l.source_filename && ` • ${l.source_filename}`}
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => deleteList(l.id, l.name)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
        )}

        <PriceListUploadModal open={modalOpen} onClose={() => setModalOpen(false)} onUploaded={fetchLists} />
      </main>
    </div>
  );
}
