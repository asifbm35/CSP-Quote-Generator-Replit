import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { AppHeader } from '@/components/AppHeader';
import { QuoteCustomerView } from '@/components/QuoteCustomerView';
import { QuoteMarginSummary } from '@/components/QuoteMarginSummary';
import { Button } from '@/components/ui/button';
import { type Currency } from '@/lib/pricing';
import type { QuoteItemRow } from '@/components/QuoteItemsEditor';
import { ArrowLeft, Eye, BarChart3, Printer, Pencil, FileSpreadsheet } from 'lucide-react';
import type { QuoteHeaderData } from '@/components/QuoteHeaderForm';
import { exportQuoteToExcel } from '@/lib/excel-export';
import { toast } from 'sonner';

export const Route = createFileRoute('/quotes/$quoteId')({
  component: QuoteDetailPage,
  head: () => ({
    meta: [
      { title: 'Quote Details — DBiz.ai' },
      { name: 'description', content: 'View quote details.' },
    ],
  }),
});

type ViewTab = 'customer' | 'margins';

function QuoteDetailPage() {
  const { quoteId } = Route.useParams();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [quote, setQuote] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ViewTab>('customer');

  useEffect(() => {
    if (!user) return;
    const fetch = async () => {
      const { data: q } = await supabase.from('quotes').select('*').eq('id', quoteId).single();
      const { data: i } = await supabase.from('quote_items').select('*').eq('quote_id', quoteId);
      setQuote(q);
      setItems(i || []);
      setLoading(false);
    };
    fetch();
  }, [quoteId, user]);

  if (authLoading || loading) {
    return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  }
  if (!user) { navigate({ to: '/login' }); return null; }
  if (!quote) {
    return (
      <div className="min-h-screen">
        <AppHeader />
        <div className="p-8 text-center text-muted-foreground">Quote not found.</div>
      </div>
    );
  }

  const header: QuoteHeaderData = {
    customerName: quote.customer_name,
    currency: quote.currency as Currency,
    customerSegment: quote.customer_segment as any,
    validTill: quote.valid_till,
    priceListMonth: quote.price_list_month,
    marginStrategy: quote.margin_strategy as any,
    uniformMargin: quote.uniform_margin ?? 10,
    region: quote.region ?? '',
    market: quote.market ?? '',
  };

  const mappedItems: QuoteItemRow[] = items.map(i => ({
    id: i.id,
    priceListItemId: i.price_list_item_id ?? undefined,
    productName: i.product_name,
    quantity: i.quantity,
    commitmentTerm: i.commitment_term as any,
    billingFrequency: i.billing_frequency as any,
    erpPrice: Number(i.erp_price),
    partnerCost: Number(i.partner_cost),
    targetMargin: Number(i.target_margin),
    derivedDiscount: Number(i.derived_discount),
    customerUnitPrice: Number(i.customer_unit_price),
    totalPrice: Number(i.total_price),
  }));

  return (
    <div className="min-h-screen">
      <div className="no-print">
        <AppHeader />
      </div>
      <main className="mx-auto max-w-5xl px-4 py-6">
        <div className="no-print mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate({ to: '/' })}>
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
            <div>
              <h1 className="text-xl font-bold text-foreground">{quote.customer_name}</h1>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                {quote.quote_number && (
                  <span className="font-mono font-semibold text-primary">{quote.quote_number}</span>
                )}
                {(header.market || header.priceListMonth) && (
                  <span>Priced from: <span className="font-medium">{header.market} / {header.currency} / {header.priceListMonth}</span></span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate({ to: '/quotes/$quoteId/edit', params: { quoteId } })}
            >
              <Pencil className="h-4 w-4" /> Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                try {
                  const safeName = (header.customerName || 'quote').replace(/[^a-z0-9-_]+/gi, '_');
                  const fname = quote.quote_number
                    ? `${quote.quote_number}.xlsx`
                    : `DBiz_Quote_${safeName}.xlsx`;
                  await exportQuoteToExcel(header, mappedItems, fname, quote.quote_number ?? undefined);
                  toast.success('Editable Excel quote downloaded');
                } catch (e) {
                  console.error(e);
                  toast.error('Failed to export Excel');
                }
              }}
            >
              <FileSpreadsheet className="h-4 w-4" /> Export to Excel
            </Button>
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="h-4 w-4" /> Print / PDF
            </Button>
          </div>
        </div>

        <div className="no-print mb-6 flex gap-1 rounded-lg bg-muted p-1">
          <button
            onClick={() => setActiveTab('customer')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'customer' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Eye className="h-3.5 w-3.5" /> Customer Quote
          </button>
          <button
            onClick={() => setActiveTab('margins')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === 'margins' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <BarChart3 className="h-3.5 w-3.5" /> Internal Margins
          </button>
        </div>

        {activeTab === 'customer' && <QuoteCustomerView header={header} items={mappedItems} quoteNumber={quote.quote_number ?? undefined} />}
        {activeTab === 'margins' && <QuoteMarginSummary items={mappedItems} currency={header.currency as Currency} customerName={header.customerName} validTill={header.validTill} quoteNumber={quote.quote_number ?? undefined} />}
      </main>
    </div>
  );
}
