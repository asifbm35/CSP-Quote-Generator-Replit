import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { AppHeader } from '@/components/AppHeader';
import { QuoteEditor } from '@/components/QuoteEditor';
import type { QuoteHeaderData } from '@/components/QuoteHeaderForm';
import { recalcItem, type PriceListItem, type QuoteItemRow } from '@/components/QuoteItemsEditor';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import type { Currency } from '@/lib/pricing';

export const Route = createFileRoute('/quotes/$quoteId_/edit')({
  component: EditQuotePage,
  head: () => ({
    meta: [
      { title: 'Edit Quote — DBiz.ai' },
      { name: 'description', content: 'Edit an existing CSP quote.' },
    ],
  }),
});

function EditQuotePage() {
  const { quoteId } = Route.useParams();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [header, setHeader] = useState<QuoteHeaderData | null>(null);
  const [items, setItems] = useState<QuoteItemRow[]>([]);
  const [priceListId, setPriceListId] = useState<string>('');
  const [priceListItems, setPriceListItems] = useState<PriceListItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: q, error: qErr } = await supabase.from('quotes').select('*').eq('id', quoteId).single();
      if (qErr || !q) { setError('Quote not found'); setLoading(false); return; }
      if (!q.price_list_id) { setError('This quote has no linked price list and cannot be edited.'); setLoading(false); return; }

      const { data: rawItems } = await supabase.from('quote_items').select('*').eq('quote_id', quoteId);
      // Page through ALL price-list items — Supabase caps a single SELECT at 1000 rows by default.
      const pli: any[] = [];
      const pageSize = 1000;
      let from = 0;
      while (true) {
        const { data: page, error: pageErr } = await supabase
          .from('partner_price_list_items')
          .select('*')
          .eq('price_list_id', q.price_list_id)
          .range(from, from + pageSize - 1);
        if (pageErr) { setError(pageErr.message); setLoading(false); return; }
        if (!page || page.length === 0) break;
        pli.push(...page);
        if (page.length < pageSize) break;
        from += pageSize;
      }

      setHeader({
        customerName: q.customer_name,
        currency: q.currency as Currency,
        customerSegment: q.customer_segment as any,
        validTill: q.valid_till,
        priceListMonth: q.price_list_month,
        marginStrategy: q.margin_strategy as any,
        uniformMargin: q.uniform_margin ?? 10,
        region: q.region ?? '',
        market: q.market ?? '',
      });
      setPriceListId(q.price_list_id);
      setPriceListItems((pli || []) as unknown as PriceListItem[]);
      setItems((rawItems || []).map(i => recalcItem({
        id: i.id,
        priceListItemId: i.price_list_item_id ?? undefined,
        productName: i.product_name,
        quantity: i.quantity,
        commitmentTerm: i.commitment_term as any,
        billingFrequency: i.billing_frequency as any,
        erpPrice: Number(i.erp_price),
        partnerCost: Number(i.partner_cost),
        targetMargin: Number(i.target_margin),
        derivedDiscount: Number(i.derived_discount),
        customerUnitPrice: Number(i.customer_unit_price),
        totalPrice: Number(i.total_price),
      })));
      setLoading(false);
    })();
  }, [quoteId, user]);

  if (authLoading || loading) return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  if (!user) { navigate({ to: '/login' }); return null; }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <div className="mb-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate({ to: '/quotes/$quoteId', params: { quoteId } })}>
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <h1 className="text-xl font-bold text-foreground">Edit Quote</h1>
        </div>

        {error ? (
          <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>
        ) : header && (
          <QuoteEditor
            mode="edit"
            quoteId={quoteId}
            initialHeader={header}
            initialItems={items}
            priceListId={priceListId}
            priceListItems={priceListItems}
          />
        )}
      </main>
    </div>
  );
}
