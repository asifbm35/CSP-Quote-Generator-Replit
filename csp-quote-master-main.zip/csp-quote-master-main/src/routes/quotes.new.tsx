import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { AppHeader } from '@/components/AppHeader';
import { QuoteEditor } from '@/components/QuoteEditor';
import type { PriceListItem } from '@/components/QuoteItemsEditor';
import { getDefaultQuoteHeader } from '@/components/QuoteHeaderForm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, AlertTriangle, Upload } from 'lucide-react';
import { CURRENCIES, type Currency } from '@/lib/pricing';
import { REGIONS, findRegion } from '@/lib/regions';

export const Route = createFileRoute('/quotes/new')({
  component: NewQuotePage,
  head: () => ({
    meta: [
      { title: 'New Quote — DBiz.ai' },
      { name: 'description', content: 'Create a new Microsoft CSP license quote.' },
    ],
  }),
});

function getCurrentMonth(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function NewQuotePage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [region, setRegion] = useState('India');
  const regionDef = findRegion(region)!;
  const [currency, setCurrency] = useState<Currency>(regionDef.currency);
  const [month, setMonth] = useState(getCurrentMonth());
  const [checking, setChecking] = useState(false);
  const [bound, setBound] = useState<{ id: string; market: string; items: PriceListItem[] } | null>(null);
  const [notFound, setNotFound] = useState(false);

  if (loading) return <div className="flex min-h-screen items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>;
  if (!user) { navigate({ to: '/login' }); return null; }

  const handleRegionChange = (r: string) => {
    setRegion(r);
    const def = findRegion(r);
    if (def) setCurrency(def.currency);
    setBound(null); setNotFound(false);
  };

  const checkAndStart = async () => {
    setChecking(true);
    setNotFound(false);
    try {
      const def = findRegion(region);
      const market = def?.market || '';
      const { data: list } = await supabase
        .from('partner_price_lists')
        .select('id, market')
        .eq('user_id', user.id)
        .eq('market', market)
        .eq('currency', currency)
        .eq('price_list_month', month)
        .maybeSingle();
      if (!list) { setNotFound(true); setBound(null); return; }
      // Page through ALL items — Supabase caps a single SELECT at 1000 rows by default.
      const allItems: PriceListItem[] = [];
      const pageSize = 1000;
      let from = 0;
      while (true) {
        const { data: page, error: pageErr } = await supabase
          .from('partner_price_list_items')
          .select('*')
          .eq('price_list_id', list.id)
          .range(from, from + pageSize - 1);
        if (pageErr) throw pageErr;
        if (!page || page.length === 0) break;
        allItems.push(...(page as unknown as PriceListItem[]));
        if (page.length < pageSize) break;
        from += pageSize;
      }
      setBound({ id: list.id, market: list.market, items: allItems });
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-5xl px-4 py-6">
        <div className="mb-4 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate({ to: '/' })}>
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <h1 className="text-xl font-bold text-foreground">New Quote</h1>
        </div>

        {!bound && (
          <div className="rounded-lg border border-border bg-card p-5">
            <h2 className="mb-1 text-sm font-semibold text-foreground">Select Price List</h2>
            <p className="mb-4 text-xs text-muted-foreground">Choose the region, currency, and month to bind this quote to a Partner Price List.</p>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label>Region</Label>
                <Select value={region} onValueChange={handleRegionChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {REGIONS.map(r => <SelectItem key={r.region} value={r.region}>{r.region}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Currency</Label>
                <Select value={currency} onValueChange={v => setCurrency(v as Currency)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Price List Month</Label>
                <Input type="month" value={month} onChange={e => setMonth(e.target.value)} />
              </div>
            </div>
            <div className="mt-4 flex items-center justify-end gap-2">
              <Button onClick={checkAndStart} disabled={checking}>
                {checking ? 'Checking...' : 'Continue'}
              </Button>
            </div>

            {notFound && (
              <div className="mt-4 rounded-md border border-destructive/40 bg-destructive/10 p-3">
                <div className="flex items-start gap-2 text-sm text-destructive">
                  <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0" />
                  <div>
                    <p className="font-medium">No Partner Price List found for {region} / {currency} / {month}.</p>
                    <p className="text-xs">Upload a price list to continue.</p>
                    <Button asChild size="sm" className="mt-2">
                      <Link to="/price-lists"><Upload className="h-4 w-4" /> Upload Price List</Link>
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {bound && (
          <QuoteEditor
            mode="new"
            initialHeader={{
              ...getDefaultQuoteHeader(),
              region,
              market: bound.market,
              currency,
              priceListMonth: month,
            }}
            initialItems={[]}
            priceListId={bound.id}
            priceListItems={bound.items}
          />
        )}
      </main>
    </div>
  );
}
