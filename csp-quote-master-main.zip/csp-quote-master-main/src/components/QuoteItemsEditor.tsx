import { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Plus, Trash2, AlertTriangle } from 'lucide-react';
import {
  type CommitmentTerm,
  type BillingFrequency,
  type Currency,
  type CustomerSegment,
  type MarginStrategy,
  calculatePricing,
  getNCEValidationMessage,
  formatCurrency,
  getBillingLabel,
} from '@/lib/pricing';

export interface PriceListItem {
  id: string;
  product_name: string;
  commitment_term: CommitmentTerm;
  billing_frequency: BillingFrequency;
  customer_segment: CustomerSegment;
  erp_price: number;
  partner_cost: number;
}

export interface QuoteItemRow {
  id: string;
  priceListItemId?: string;
  productName: string;
  quantity: number;
  commitmentTerm: CommitmentTerm;
  billingFrequency: BillingFrequency;
  erpPrice: number;
  partnerCost: number;
  targetMargin: number;
  derivedDiscount: number;
  customerUnitPrice: number;
  totalPrice: number;
  nceError?: string;
  pricingError?: string;
}

interface Props {
  items: QuoteItemRow[];
  onChange: (items: QuoteItemRow[]) => void;
  currency: Currency;
  marginStrategy: MarginStrategy;
  uniformMargin: number;
  customerSegment: CustomerSegment;
  priceListItems: PriceListItem[];
}

export function createEmptyItem(marginStrategy: MarginStrategy, uniformMargin: number): QuoteItemRow {
  return {
    id: crypto.randomUUID(),
    productName: '',
    quantity: 1,
    commitmentTerm: 'Annual',
    billingFrequency: 'Annual',
    erpPrice: 0,
    partnerCost: 0,
    targetMargin: marginStrategy === 'uniform' ? uniformMargin : 10,
    derivedDiscount: 0,
    customerUnitPrice: 0,
    totalPrice: 0,
  };
}

export function recalcItem(item: QuoteItemRow): QuoteItemRow {
  const nceError = getNCEValidationMessage(item.commitmentTerm, item.billingFrequency) || undefined;
  if (nceError) return { ...item, nceError, pricingError: undefined };
  if (item.partnerCost < 0 || item.erpPrice < 0) {
    return { ...item, nceError: undefined, pricingError: undefined, customerUnitPrice: 0, totalPrice: 0, derivedDiscount: 0 };
  }
  const result = calculatePricing({
    erpPrice: item.erpPrice,
    partnerCost: item.partnerCost,
    targetMargin: item.targetMargin,
    quantity: item.quantity,
    commitmentTerm: item.commitmentTerm,
    billingFrequency: item.billingFrequency,
  });
  return {
    ...item,
    nceError: undefined,
    pricingError: result.error,
    customerUnitPrice: result.customerUnitPrice,
    totalPrice: result.totalPrice,
    derivedDiscount: result.derivedDiscount,
  };
}

export function QuoteItemsEditor({ items, onChange, currency, marginStrategy, uniformMargin, customerSegment, priceListItems }: Props) {
  const [search, setSearch] = useState<Record<string, string>>({});

  // Distinct products for the current segment
  const productsForSegment = useMemo(() => {
    const set = new Set<string>();
    priceListItems
      .filter(p => p.customer_segment === customerSegment)
      .forEach(p => set.add(p.product_name));
    return Array.from(set).sort();
  }, [priceListItems, customerSegment]);

  // For a given product, the available commitment+billing combos
  const combosForProduct = (productName: string) => {
    return priceListItems.filter(p => p.product_name === productName && p.customer_segment === customerSegment);
  };

  const addItem = () => onChange([...items, createEmptyItem(marginStrategy, uniformMargin)]);
  const removeItem = (id: string) => onChange(items.filter(i => i.id !== id));

  const setRow = (id: string, mutator: (r: QuoteItemRow) => QuoteItemRow) => {
    onChange(items.map(i => {
      if (i.id !== id) return i;
      let r = mutator(i);
      if (marginStrategy === 'uniform') r = { ...r, targetMargin: uniformMargin };
      return recalcItem(r);
    }));
  };

  const selectProduct = (id: string, productName: string) => {
    const combos = combosForProduct(productName);
    if (combos.length === 0) {
      setRow(id, r => ({ ...r, productName, priceListItemId: undefined, erpPrice: 0, partnerCost: 0 }));
      return;
    }
    const first = combos.find(c => !getNCEValidationMessage(c.commitment_term, c.billing_frequency)) ?? combos[0];
    setRow(id, r => ({
      ...r,
      productName,
      priceListItemId: first.id,
      commitmentTerm: first.commitment_term,
      billingFrequency: first.billing_frequency,
      erpPrice: Number(first.erp_price),
      partnerCost: Number(first.partner_cost),
    }));
  };

  const selectCombo = (id: string, commitment: CommitmentTerm, billing: BillingFrequency, productName: string) => {
    const match = priceListItems.find(p =>
      p.product_name === productName &&
      p.customer_segment === customerSegment &&
      p.commitment_term === commitment &&
      p.billing_frequency === billing
    );
    setRow(id, r => ({
      ...r,
      commitmentTerm: commitment,
      billingFrequency: billing,
      priceListItemId: match?.id,
      erpPrice: match ? Number(match.erp_price) : 0,
      partnerCost: match ? Number(match.partner_cost) : 0,
    }));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">Line Items</h3>
        <Button size="sm" onClick={addItem} disabled={productsForSegment.length === 0}>
          <Plus className="h-4 w-4" /> Add Product
        </Button>
      </div>

      {productsForSegment.length === 0 && (
        <div className="rounded-md border border-warning/30 bg-warning/10 p-3 text-xs text-warning-foreground">
          No products available in this price list for segment "{customerSegment}".
        </div>
      )}

      {items.length === 0 && productsForSegment.length > 0 && (
        <div className="rounded-lg border border-dashed border-border p-8 text-center text-muted-foreground">
          No items yet. Click "Add Product" to start building your quote.
        </div>
      )}

      {items.map((item, idx) => {
        const combos = item.productName ? combosForProduct(item.productName) : [];
        const distinctCommitments = Array.from(new Set(combos.map(c => c.commitment_term)));
        const billingsForCommitment = Array.from(new Set(combos.filter(c => c.commitment_term === item.commitmentTerm).map(c => c.billing_frequency)));
        const searchVal = search[item.id] ?? item.productName;
        const filteredProducts = productsForSegment.filter(p => p.toLowerCase().includes(searchVal.toLowerCase())).slice(0, 8);

        return (
          <div key={item.id} className="rounded-lg border border-border bg-card p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-muted-foreground">Serial #&nbsp;{idx + 1}</span>
              <Button variant="ghost" size="icon" onClick={() => removeItem(item.id)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <div className="relative space-y-1 sm:col-span-2">
                <Label className="text-xs">Product</Label>
                <Input
                  value={searchVal}
                  onChange={e => setSearch(s => ({ ...s, [item.id]: e.target.value }))}
                  onBlur={() => setTimeout(() => setSearch(s => { const n = { ...s }; delete n[item.id]; return n; }), 150)}
                  placeholder="Search product from price list"
                />
                {search[item.id] !== undefined && filteredProducts.length > 0 && (
                  <div className="absolute z-10 mt-1 max-h-60 w-full overflow-y-auto rounded-md border border-border bg-popover shadow-md">
                    {filteredProducts.map(p => (
                      <button
                        key={p}
                        className="w-full px-3 py-2 text-left text-sm hover:bg-accent"
                        onMouseDown={() => { selectProduct(item.id, p); setSearch(s => { const n = { ...s }; delete n[item.id]; return n; }); }}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Quantity</Label>
                <Input type="number" min={1} value={item.quantity} onChange={e => setRow(item.id, r => ({ ...r, quantity: parseInt(e.target.value) || 1 }))} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Commitment</Label>
                <Select
                  value={item.commitmentTerm}
                  onValueChange={(v) => {
                    const next = v as CommitmentTerm;
                    const billings = combos.filter(c => c.commitment_term === next).map(c => c.billing_frequency);
                    const newBilling = billings.includes(item.billingFrequency) ? item.billingFrequency : (billings[0] ?? item.billingFrequency);
                    selectCombo(item.id, next, newBilling, item.productName);
                  }}
                  disabled={!item.productName}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {distinctCommitments.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Billing Frequency</Label>
                <Select
                  value={item.billingFrequency}
                  onValueChange={(v) => selectCombo(item.id, item.commitmentTerm, v as BillingFrequency, item.productName)}
                  disabled={!item.productName}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {billingsForCommitment.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">ERP @ commitment</Label>
                <Input value={item.erpPrice ? item.erpPrice.toFixed(2) : ''} readOnly disabled placeholder="auto" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Partner Cost @ commitment</Label>
                <Input value={item.partnerCost ? item.partnerCost.toFixed(2) : ''} readOnly disabled placeholder="auto" />
              </div>
              {marginStrategy === 'per_product' && (
                <div className="space-y-1">
                  <Label className="text-xs">Margin (%)</Label>
                  <Input type="number" min={0} max={99} step={0.5} value={item.targetMargin} onChange={e => setRow(item.id, r => ({ ...r, targetMargin: parseFloat(e.target.value) || 0 }))} />
                </div>
              )}
            </div>

            {item.nceError && (
              <div className="flex items-center gap-2 rounded-md bg-destructive/10 p-2 text-xs text-destructive">
                <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0" /> {item.nceError}
              </div>
            )}
            {item.pricingError && (
              <div className="flex items-center gap-2 rounded-md bg-warning/10 p-2 text-xs text-warning-foreground">
                <AlertTriangle className="h-3.5 w-3.5 flex-shrink-0" /> {item.pricingError}
              </div>
            )}

            {item.customerUnitPrice > 0 && !item.nceError && !item.pricingError && (
              <div className="flex flex-wrap gap-4 border-t border-border pt-2 text-xs text-muted-foreground">
                <span>Unit: <strong className="text-foreground">{formatCurrency(item.customerUnitPrice, currency)}</strong>{getBillingLabel(item.billingFrequency)}</span>
                <span>Total: <strong className="text-foreground">{formatCurrency(item.totalPrice, currency)}</strong></span>
                <span>Discount: <strong className="text-foreground">{item.derivedDiscount.toFixed(2)}%</strong></span>
              </div>
            )}
          </div>
        );
      })}

      {items.length > 0 && productsForSegment.length > 0 && (
        <Button
          variant="outline"
          onClick={addItem}
          className="w-full border-dashed border-border text-muted-foreground hover:text-foreground"
        >
          <Plus className="h-4 w-4" /> Add Product
        </Button>
      )}
    </div>
  );
}
