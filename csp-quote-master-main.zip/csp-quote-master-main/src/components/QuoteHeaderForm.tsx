import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SEGMENTS, type Currency, type CustomerSegment, type MarginStrategy } from '@/lib/pricing';

export interface QuoteHeaderData {
  customerName: string;
  currency: Currency;
  customerSegment: CustomerSegment;
  validTill: string;
  priceListMonth: string;
  marginStrategy: MarginStrategy;
  uniformMargin: number;
  region: string;
  market: string;
}

interface Props {
  data: QuoteHeaderData;
  onChange: (data: QuoteHeaderData) => void;
  /** When true, region/market/currency/month are read-only (bound to a price list). */
  bindingLocked?: boolean;
}

function getCurrentMonth(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

export function getDefaultQuoteHeader(): QuoteHeaderData {
  const validTill = new Date();
  validTill.setDate(validTill.getDate() + 30);
  return {
    customerName: '',
    currency: 'INR',
    customerSegment: 'Commercial',
    validTill: validTill.toISOString().split('T')[0],
    priceListMonth: getCurrentMonth(),
    marginStrategy: 'uniform',
    uniformMargin: 10,
    region: 'India',
    market: 'IN',
  };
}

export function QuoteHeaderForm({ data, onChange, bindingLocked = true }: Props) {
  const update = (field: keyof QuoteHeaderData, value: string | number) => {
    onChange({ ...data, [field]: value });
  };

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <div className="space-y-1.5">
        <Label htmlFor="customerName">Customer Name</Label>
        <Input
          id="customerName"
          value={data.customerName}
          onChange={e => update('customerName', e.target.value)}
          placeholder="Enter customer name"
        />
      </div>
      <div className="space-y-1.5">
        <Label>Region</Label>
        <Input value={data.region} disabled={bindingLocked} readOnly={bindingLocked} />
      </div>
      <div className="space-y-1.5">
        <Label>Market</Label>
        <Input value={data.market} disabled={bindingLocked} readOnly={bindingLocked} />
      </div>
      <div className="space-y-1.5">
        <Label>Currency</Label>
        <Input value={data.currency} disabled={bindingLocked} readOnly={bindingLocked} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="priceListMonth">Price List Month</Label>
        <Input
          id="priceListMonth"
          type="month"
          value={data.priceListMonth}
          disabled={bindingLocked}
          readOnly={bindingLocked}
        />
      </div>
      <div className="space-y-1.5">
        <Label>Customer Segment</Label>
        <Select value={data.customerSegment} onValueChange={v => update('customerSegment', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {SEGMENTS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="validTill">Quote Valid Till</Label>
        <Input
          id="validTill"
          type="date"
          value={data.validTill}
          onChange={e => update('validTill', e.target.value)}
        />
      </div>
      <div className="space-y-1.5">
        <Label>Margin Strategy</Label>
        <Select value={data.marginStrategy} onValueChange={v => update('marginStrategy', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="uniform">Same margin for all products</SelectItem>
            <SelectItem value="per_product">Different margin per product</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {data.marginStrategy === 'uniform' && (
        <div className="space-y-1.5">
          <Label htmlFor="uniformMargin">Uniform Margin (%)</Label>
          <Input
            id="uniformMargin"
            type="number"
            min={0}
            max={99}
            step={0.5}
            value={data.uniformMargin}
            onChange={e => update('uniformMargin', parseFloat(e.target.value) || 0)}
          />
        </div>
      )}
    </div>
  );
}
