import type { QuoteItemRow } from '@/components/QuoteItemsEditor';
import type { QuoteHeaderData } from '@/components/QuoteHeaderForm';
import { formatCurrency, getBillingLabel, type Currency, type CommitmentTerm, type BillingFrequency } from '@/lib/pricing';
import { QuoteBrandedHeader } from '@/components/QuoteBrandedHeader';

interface Props {
  header: QuoteHeaderData;
  items: QuoteItemRow[];
  quoteNumber?: string;
}

const TERM_ORDER: CommitmentTerm[] = ['Monthly', 'Annual', 'Triennial'];
const BILLING_ORDER: BillingFrequency[] = ['Monthly', 'Annual', 'Triennial'];

export function QuoteCustomerView({ header, items, quoteNumber }: Props) {
  const validItems = items.filter(i => i.customerUnitPrice > 0 && !i.nceError && !i.pricingError);
  const grandTotal = validItems.reduce((sum, i) => sum + i.totalPrice, 0);
  const currency = header.currency as Currency;

  const groups: { term: CommitmentTerm; billing: BillingFrequency; rows: QuoteItemRow[] }[] = [];
  for (const term of TERM_ORDER) {
    for (const billing of BILLING_ORDER) {
      const rows = validItems.filter(i => i.commitmentTerm === term && i.billingFrequency === billing);
      if (rows.length > 0) groups.push({ term, billing, rows });
    }
  }

  let serial = 0;

  return (
    <div
      className="mx-auto my-6 max-w-3xl rounded-xl border-2 border-border bg-card p-10 shadow-lg print:my-0 print:rounded-none print:border-2 print:p-8 print:shadow-none"
      style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact', borderColor: '#1e40af' } as React.CSSProperties}
    >
      <QuoteBrandedHeader customerName={header.customerName} validTill={header.validTill} quoteNumber={quoteNumber} />

      <div
        className="mb-6 rounded-lg p-4"
        style={{
          backgroundColor: 'var(--primary)',
          color: 'var(--primary-foreground)',
          printColorAdjust: 'exact',
          WebkitPrintColorAdjust: 'exact',
        } as React.CSSProperties}
      >
        <p className="text-xs uppercase tracking-wide opacity-80">Prepared for</p>
        <p className="text-lg font-semibold">{header.customerName || 'Customer Name'}</p>
        <p className="text-xs opacity-90">Segment: {header.customerSegment} • Currency: {header.currency}</p>
      </div>

      {/* Items Table */}
      <table className="mb-6 w-full text-sm border-separate rounded-lg border border-border overflow-hidden" style={{ borderSpacing: 0 }}>
        <thead>
          <tr
            style={{
              backgroundColor: 'var(--primary)',
              color: 'var(--primary-foreground)',
              printColorAdjust: 'exact',
              WebkitPrintColorAdjust: 'exact',
            } as React.CSSProperties}
          >
            <th className="py-2.5 pl-3 pr-8 text-left font-semibold whitespace-nowrap w-24 rounded-l-md">Serial #</th>
            <th className="py-2.5 px-4 text-left font-semibold">Description</th>
            <th className="py-2.5 px-4 text-center font-semibold whitespace-nowrap">Quantity</th>
            <th className="py-2.5 px-4 text-right font-semibold whitespace-nowrap">Unit Price</th>
            <th className="py-2.5 pl-4 pr-3 text-right font-semibold whitespace-nowrap rounded-r-md">Total Price</th>
          </tr>
        </thead>
        {groups.map(({ term, billing, rows }) => (
          <tbody key={`${term}-${billing}`}>
            <tr
              style={{
                backgroundColor: 'var(--secondary)',
                color: 'var(--secondary-foreground)',
                printColorAdjust: 'exact',
                WebkitPrintColorAdjust: 'exact',
              } as React.CSSProperties}
            >
              <td colSpan={5} className="py-2 px-3 text-xs font-semibold uppercase tracking-wide">
                NCE Commitment Type – {term} Commitment ({billing} Billing)
              </td>
            </tr>
            {rows.map((item) => {
              serial += 1;
              return (
                <tr key={item.id} className="border-b border-border">
                  <td className="py-3 pr-8 text-muted-foreground tabular-nums align-top">{serial}</td>
                  <td className="py-3 px-4 font-medium text-foreground align-top">{item.productName}</td>
                  <td className="py-3 px-4 text-center text-foreground align-top tabular-nums">{item.quantity}</td>
                  <td className="py-3 px-4 text-right text-foreground align-top tabular-nums whitespace-nowrap">
                    {formatCurrency(item.customerUnitPrice, currency)}{getBillingLabel(item.billingFrequency)}
                  </td>
                  <td className="py-3 pl-4 text-right font-medium text-foreground align-top tabular-nums whitespace-nowrap">
                    {formatCurrency(item.totalPrice, currency)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        ))}
        <tfoot>
          <tr className="border-t-2 border-primary/20">
            <td colSpan={4} className="py-4 pr-4 text-right font-semibold text-foreground">Grand Total</td>
            <td className="py-4 pl-4 text-right text-lg font-bold text-primary tabular-nums whitespace-nowrap">{formatCurrency(grandTotal, currency)}</td>
          </tr>
        </tfoot>
      </table>

      {/* Footer */}
      <div className="mt-8 border-t border-border pt-4 text-xs text-muted-foreground">
        <p>• All prices are exclusive of applicable taxes.</p>
        <p>• This quote is valid until {header.validTill}.</p>
        <p className="mt-2">Generated by DBiz.ai CSP Quote Generator</p>
      </div>
    </div>
  );
}
