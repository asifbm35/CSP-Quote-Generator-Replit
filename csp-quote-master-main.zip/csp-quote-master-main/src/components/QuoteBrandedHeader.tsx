import dbizLogo from '@/assets/dbiz-logo.png';

interface Props {
  customerName: string;
  validTill: string;
  /** Optional small label shown under "Valid Till" row, e.g. "Internal Margin View" */
  documentLabel?: string;
  /** Optional unique quote number (e.g. DBIZ-Q-IN-ACME-260416-012) */
  quoteNumber?: string;
}

/**
 * Branded DBiz.ai quote header — black hero band that mirrors the manual quote.
 * Uses inline styles for colors that must survive print/PDF export.
 */
export function QuoteBrandedHeader({ customerName, validTill, documentLabel, quoteNumber }: Props) {
  return (
    <div
      className="relative mb-6 flex items-center justify-between gap-6 overflow-hidden rounded-xl px-8 py-6 text-white shadow-xl print:rounded-none print:shadow-none"
      style={{
        backgroundColor: '#000000',
        color: '#ffffff',
        printColorAdjust: 'exact',
        WebkitPrintColorAdjust: 'exact',
        borderBottom: '3px solid #1e40af',
      } as React.CSSProperties}
    >
      {/* Left: Logo + tagline */}
      <div className="flex items-center gap-5">
        <div
          className="flex items-center justify-center rounded-lg px-4 py-3 shadow-md"
          style={{
            backgroundColor: '#ffffff',
            printColorAdjust: 'exact',
            WebkitPrintColorAdjust: 'exact',
          } as React.CSSProperties}
        >
          <img src={dbizLogo} alt="DBiz.ai" className="h-12 w-auto" />
        </div>
        <div className="border-l border-white/30 pl-5 leading-tight">
          <p className="text-lg font-extrabold tracking-wide" style={{ color: '#ffffff' }}>
            IMPACT<span style={{ color: '#ff6a13' }}>FUL</span>
          </p>
          <p className="text-sm font-semibold tracking-[0.18em]" style={{ color: 'rgba(255,255,255,0.92)' }}>
            EXPERIENCE
          </p>
          <p className="text-sm font-semibold tracking-[0.28em]" style={{ color: 'rgba(255,255,255,0.92)' }}>
            <span style={{ color: '#ff6a13' }}>@</span> S C<span style={{ color: '#ff6a13' }}> A </span>L E
          </p>
        </div>
      </div>

      {/* Right: Reseller / Contact / Organization / Valid Till */}
      <div className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-xs">
        <span className="font-semibold" style={{ color: '#ffffff' }}>Reseller Name</span>
        <span style={{ color: 'rgba(255,255,255,0.95)' }}>DBiz.AI</span>
        <span className="font-semibold" style={{ color: '#ffffff' }}>Contact</span>
        <span style={{ color: 'rgba(255,255,255,0.95)' }}>
          Abhi Chandra
          <br />
          <span style={{ color: 'rgba(255,255,255,0.8)' }}>abhi.chandra@dbizsolution.com</span>
        </span>
        <span className="col-span-2 h-2" />
        <span className="font-semibold" style={{ color: '#ffffff' }}>Organization</span>
        <span className="font-medium" style={{ color: '#ff6a13' }}>{customerName || 'Insert Organization'}</span>
        <span className="font-semibold" style={{ color: '#ffffff' }}>Valid Till</span>
        <span className="font-medium" style={{ color: '#ff6a13' }}>{validTill || 'Insert valid till date'}</span>
        {quoteNumber && (
          <>
            <span className="font-semibold" style={{ color: '#ffffff' }}>Quote #</span>
            <span className="font-mono text-[11px] font-semibold tracking-wide" style={{ color: '#ff6a13' }}>{quoteNumber}</span>
          </>
        )}
        {documentLabel && (
          <>
            <span className="col-span-2 h-1" />
            <span className="col-span-2 text-[10px] uppercase tracking-[0.2em]" style={{ color: 'rgba(255,255,255,0.7)' }}>
              {documentLabel}
            </span>
          </>
        )}
      </div>
    </div>
  );
}
