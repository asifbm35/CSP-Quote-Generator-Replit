import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { signOut } from '@/lib/auth';
import { useAuth } from '@/hooks/use-auth';
import { LogOut, Database, BookOpen } from 'lucide-react';
import dbizLogo from '@/assets/dbiz-logo.png';

export function AppHeader() {
  const { user } = useAuth();

  return (
    <header className="border-b border-border bg-card">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center gap-3">
            <img src={dbizLogo} alt="DBiz.ai" className="h-8 w-auto" />
            <span className="hidden border-l border-border pl-3 text-xs font-medium text-muted-foreground sm:inline">CSP Quote Generator</span>
          </Link>
          {user && (
            <nav className="hidden items-center gap-1 sm:flex">
              <Link
                to="/"
                activeProps={{ className: 'bg-accent text-foreground' }}
                activeOptions={{ exact: true }}
                className="rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                Quotes
              </Link>
              <Link
                to="/price-lists"
                activeProps={{ className: 'bg-accent text-foreground' }}
                className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <Database className="h-3.5 w-3.5" /> Price Lists
              </Link>
              <Link
                to="/user-guide"
                activeProps={{ className: 'bg-accent text-foreground' }}
                className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <BookOpen className="h-3.5 w-3.5" /> User Guide
              </Link>
            </nav>
          )}
        </div>
        {user && (
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-muted-foreground md:inline">{user.email}</span>
            <Button variant="ghost" size="sm" onClick={() => signOut()}>
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        )}
      </div>
    </header>
  );
}
