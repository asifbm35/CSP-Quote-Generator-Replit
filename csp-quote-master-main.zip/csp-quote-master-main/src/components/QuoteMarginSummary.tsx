import type { QuoteItemRow } from '@/components/QuoteItemsEditor';
import { type Currency, type CommitmentTerm, type BillingFrequency, formatCurrency } from '@/lib/pricing';
import { QuoteBrandedHeader } from '@/components/QuoteBrandedHeader';

interface Props {
  items: QuoteItemRow[];
  currency: Currency;
  /** Optional — when provided, renders the branded DBiz.ai header on top */
  customerName?: string;
  validTill?: string;
  quoteNumber?: string;
}

const TERM_ORDER: CommitmentTerm[] = ['Monthly', 'Annual', 'Triennial'];
const BILLING_ORDER: BillingFrequency[] = ['Monthly', 'Annual', 'Triennial'];

export function QuoteMarginSummary({ items, currency, customerName, validTill, quoteNumber }: Props) {
  const validItems = items.filter(i => i.customerUnitPrice > 0 && !i.nceError && !i.pricingError);

  // Normalize Partner Cost from Commitment Frequency to Billing Frequency for profit math only.
  // Display values (ERP, Partner Cost) remain unchanged.
  const billingFactor = (commitment: CommitmentTerm, billing: BillingFrequency): number => {
    if (commitment === 'Annual' && billing === 'Monthly') return 1 / 12;
    if (commitment === 'Triennial' && billing === 'Monthly') return 1 / 36;
    if (commitment === 'Triennial' && billing === 'Annual') return 1 / 3;
    return 1; // same frequency
  };
  const normalizedCost = (i: QuoteItemRow) =>
    i.partnerCost * i.quantity * billingFactor(i.commitmentTerm, i.billingFrequency);

  const totalRevenue = validItems.reduce((s, i) => s + i.totalPrice, 0);
  const totalCost = validItems.reduce((s, i) => s + normalizedCost(i), 0);
  const totalProfit = totalRevenue - totalCost;
  const blendedMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

  const groups: { term: CommitmentTerm; billing: BillingFrequency; rows: QuoteItemRow[] }[] = [];
  for (const term of TERM_ORDER) {
    for (const billing of BILLING_ORDER) {
      const rows = validItems.filter(i => i.commitmentTerm === term && i.billingFrequency === billing);
      if (rows.length > 0) groups.push({ term, billing, rows });
    }
  }

  const showHeader = customerName !== undefined || validTill !== undefined;

  return (
    <div
      className="mx-auto my-6 max-w-5xl rounded-xl border-2 bg-card p-10 shadow-lg print:my-0 print:rounded-none print:border-2 print:p-8 print:shadow-none"
      style={{ printColorAdjust: 'exact', WebkitPrintColorAdjust: 'exact', borderColor: '#1e40af' } as React.CSSProperties}
    >
      {showHeader && (
        <QuoteBrandedHeader
          customerName={customerName ?? ''}
          validTill={validTill ?? ''}
          documentLabel="Internal Margin View — Confidential"
          quoteNumber={quoteNumber}
        />
      )}

      <h3 className="mb-3 text-sm font-semibold text-foreground">Internal Margin Summary</h3>
      <div className="overflow-hidden rounded-lg border-2 border-border bg-card">
        <table className="w-full text-sm border-separate" style={{ borderSpacing: 0 }}>
          <thead>
            <tr
              style={{
                backgroundColor: 'var(--primary)',
                color: 'var(--primary-foreground)',
                printColorAdjust: 'exact',
                WebkitPrintColorAdjust: 'exact',
              } as React.CSSProperties}
            >
              <th className="p-2.5 text-left font-semibold">Product</th>
              <th className="p-2.5 text-center font-semibold">Qty</th>
              <th className="p-2.5 text-right font-semibold">ERP</th>
              <th className="p-2.5 text-right font-semibold">Partner Cost</th>
              <th className="p-2.5 text-right font-semibold">Customer Price</th>
              <th className="p-2.5 text-right font-semibold">Margin %</th>
              <th className="p-2.5 text-right font-semibold">Profit</th>
            </tr>
          </thead>
          {groups.map(({ term, billing, rows }) => (
            <tbody key={`${term}-${billing}`}>
              <tr
                style={{
                  backgroundColor: 'var(--secondary)',
                  color: 'var(--secondary-foreground)',
                  printColorAdjust: 'exact',
                  WebkitPrintColorAdjust: 'exact',
                } as React.CSSProperties}
              >
                <td colSpan={7} className="py-2 px-3 text-xs font-semibold uppercase tracking-wide">
                  NCE Commitment Type – {term} Commitment ({billing} Billing)
                </td>
              </tr>
              {rows.map(item => {
                const profit = item.totalPrice - normalizedCost(item);
                return (
                  <tr key={item.id} className="border-b border-border">
                    <td className="p-2.5 font-medium text-foreground">{item.productName}</td>
                    <td className="p-2.5 text-center text-foreground tabular-nums">{item.quantity}</td>
                    <td className="p-2.5 text-right text-muted-foreground tabular-nums">{formatCurrency(item.erpPrice * item.quantity, currency)}</td>
                    <td className="p-2.5 text-right text-muted-foreground tabular-nums">{formatCurrency(item.partnerCost * item.quantity, currency)}</td>
                    <td className="p-2.5 text-right text-foreground tabular-nums">{formatCurrency(item.totalPrice, currency)}</td>
                    <td className="p-2.5 text-right font-medium text-primary tabular-nums">{item.targetMargin.toFixed(2)}%</td>
                    <td className="p-2.5 text-right font-medium text-success tabular-nums">{formatCurrency(profit, currency)}</td>
                  </tr>
                );
              })}
            </tbody>
          ))}
          <tfoot>
            <tr className="bg-muted/60">
              <td colSpan={3} className="p-2.5 font-semibold text-foreground">Totals</td>
              <td className="p-2.5 text-right font-semibold text-muted-foreground tabular-nums">{formatCurrency(totalCost, currency)}</td>
              <td className="p-2.5 text-right font-semibold text-foreground tabular-nums">{formatCurrency(totalRevenue, currency)}</td>
              <td className="p-2.5 text-right font-semibold text-primary tabular-nums">{blendedMargin.toFixed(2)}%</td>
              <td className="p-2.5 text-right font-semibold text-success tabular-nums">{formatCurrency(totalProfit, currency)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
