import { useEffect, useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { QuoteHeaderForm, type QuoteHeaderData } from '@/components/QuoteHeaderForm';
import { QuoteItemsEditor, recalcItem, type QuoteItemRow, type PriceListItem } from '@/components/QuoteItemsEditor';
import { QuoteCustomerView } from '@/components/QuoteCustomerView';
import { QuoteMarginSummary } from '@/components/QuoteMarginSummary';
import { type Currency, isLossMaking } from '@/lib/pricing';
import { Save, Eye, BarChart3 } from 'lucide-react';
import { generateQuoteNumber } from '@/lib/quote-number';

interface Props {
  mode: 'new' | 'edit';
  quoteId?: string;
  initialHeader: QuoteHeaderData;
  initialItems: QuoteItemRow[];
  priceListId: string;
  priceListItems: PriceListItem[];
}

type ViewTab = 'edit' | 'preview' | 'margins';

export function QuoteEditor({ mode, quoteId, initialHeader, initialItems, priceListId, priceListItems }: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [header, setHeader] = useState<QuoteHeaderData>(initialHeader);
  const [items, setItems] = useState<QuoteItemRow[]>(initialItems);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<ViewTab>('edit');

  // When margin strategy / uniform margin changes, recalc all rows
  useEffect(() => {
    if (header.marginStrategy === 'uniform') {
      setItems(prev => prev.map(i => recalcItem({ ...i, targetMargin: header.uniformMargin })));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [header.uniformMargin, header.marginStrategy]);

  // When segment changes, prune items whose product no longer exists for that segment
  useEffect(() => {
    setItems(prev => prev.map(i => {
      const stillValid = priceListItems.some(p =>
        p.product_name === i.productName &&
        p.customer_segment === header.customerSegment &&
        p.commitment_term === i.commitmentTerm &&
        p.billing_frequency === i.billingFrequency
      );
      if (!stillValid) {
        return { ...i, priceListItemId: undefined, productName: '', erpPrice: 0, partnerCost: 0, customerUnitPrice: 0, totalPrice: 0, derivedDiscount: 0, nceError: undefined, pricingError: undefined };
      }
      return i;
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [header.customerSegment]);

  const validItems = items.filter(i => i.customerUnitPrice > 0 && !i.nceError && !i.pricingError);
  const hasErrors = items.some(i => i.nceError || i.pricingError);
  const lossMaking = validItems.some(i => {
    const unitAtCommitment = i.partnerCost / (1 - i.targetMargin / 100);
    return isLossMaking(i.partnerCost, unitAtCommitment);
  });
  const missingProvenance = validItems.some(i => !i.priceListItemId);
  const canSave = !!header.customerName.trim() && validItems.length > 0 && !hasErrors && !missingProvenance && !lossMaking;

  const save = async () => {
    if (!canSave || !user) return;
    setSaving(true);
    try {
      // Both 'new' and 'edit' create a new quote record (versioned behavior).
      // Editing an existing quote leaves the original untouched and inserts a new copy.
      const quoteNumber = await generateQuoteNumber({
        region: header.region,
        market: header.market,
        customerName: header.customerName,
        userId: user.id,
      });
      const { data, error } = await supabase.from('quotes').insert({
        user_id: user.id,
        customer_name: header.customerName,
        currency: header.currency,
        customer_segment: header.customerSegment,
        valid_till: header.validTill,
        price_list_month: header.priceListMonth,
        margin_strategy: header.marginStrategy,
        uniform_margin: header.uniformMargin,
        status: 'draft',
        region: header.region,
        market: header.market,
        price_list_id: priceListId,
        quote_number: quoteNumber,
      }).select().single();
      if (error) throw error;
      const savedQuoteId = data.id;

      const itemsToInsert = validItems.map(i => ({
        quote_id: savedQuoteId,
        product_name: i.productName,
        quantity: i.quantity,
        commitment_term: i.commitmentTerm,
        billing_frequency: i.billingFrequency,
        erp_price: i.erpPrice,
        partner_cost: i.partnerCost,
        target_margin: i.targetMargin,
        derived_discount: i.derivedDiscount,
        customer_unit_price: i.customerUnitPrice,
        total_price: i.totalPrice,
        price_list_item_id: i.priceListItemId,
      }));
      const { error: itemsError } = await supabase.from('quote_items').insert(itemsToInsert);
      if (itemsError) throw itemsError;

      navigate({ to: '/quotes/$quoteId', params: { quoteId: savedQuoteId } });
    } catch (err: any) {
      alert('Failed to save: ' + (err.message || 'Unknown error'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="mb-6 flex gap-1 rounded-lg bg-muted p-1">
        {([['edit', 'Edit', null], ['preview', 'Customer View', Eye], ['margins', 'Margin Summary', BarChart3]] as const).map(([key, label, Icon]) => (
          <button
            key={key}
            onClick={() => setActiveTab(key as ViewTab)}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeTab === key ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {Icon && <Icon className="h-3.5 w-3.5" />}
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'edit' && (
        <div className="space-y-6">
          <div className="rounded-lg border border-border bg-card p-5">
            <h2 className="mb-4 text-sm font-semibold text-foreground">Quote Details</h2>
            <QuoteHeaderForm data={header} onChange={setHeader} bindingLocked />
            <p className="mt-3 text-xs text-muted-foreground">
              Priced from: <span className="font-medium text-foreground">{header.market} / {header.currency} / {header.priceListMonth}</span>
            </p>
          </div>

          <QuoteItemsEditor
            items={items}
            onChange={setItems}
            currency={header.currency as Currency}
            marginStrategy={header.marginStrategy}
            uniformMargin={header.uniformMargin}
            customerSegment={header.customerSegment}
            priceListItems={priceListItems}
          />

          <div className="flex items-center justify-between border-t border-border pt-4">
            <p className="text-sm text-muted-foreground">
              {validItems.length} valid item{validItems.length !== 1 ? 's' : ''}
              {hasErrors && ' • Some items have errors'}
              {missingProvenance && ' • Some items missing price list link'}
            </p>
            <Button onClick={save} disabled={!canSave || saving}>
              <Save className="h-4 w-4" /> {saving ? 'Saving...' : mode === 'edit' ? 'Save as New Version' : 'Save Quote'}
            </Button>
          </div>
        </div>
      )}

      {activeTab === 'preview' && <QuoteCustomerView header={header} items={items} />}
      {activeTab === 'margins' && <QuoteMarginSummary items={items} currency={header.currency as Currency} customerName={header.customerName} validTill={header.validTill} />}
    </div>
  );
}
