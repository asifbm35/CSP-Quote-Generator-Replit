import { useState } from 'react';
import Papa from 'papaparse';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/use-auth';
import { CURRENCIES, SEGMENTS, isValidNCECombination, type Currency, type CommitmentTerm, type BillingFrequency, type CustomerSegment } from '@/lib/pricing';
import { REGIONS, findRegion, buildPriceListName } from '@/lib/regions';
import { AlertTriangle, Upload, CheckCircle2 } from 'lucide-react';

interface Props {
  open: boolean;
  onClose: () => void;
  onUploaded: () => void;
}

interface ParsedRow {
  product_name: string;
  product_sku: string | null;
  commitment_term: CommitmentTerm;
  billing_frequency: BillingFrequency;
  customer_segment: CustomerSegment;
  erp_price: number;
  partner_cost: number;
}

function getCurrentMonth(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function pick(row: Record<string, any>, ...keys: string[]): string {
  for (const k of keys) {
    const found = Object.keys(row).find(rk => rk.toLowerCase().trim() === k.toLowerCase());
    if (found && row[found] != null && String(row[found]).trim() !== '') return String(row[found]).trim();
  }
  return '';
}

// --- Microsoft Partner Center NCE normalizers ---
function normalizeCommitment(raw: string): string {
  const v = raw.trim().toUpperCase();
  if (v === 'P1M') return 'Monthly';
  if (v === 'P1Y') return 'Annual';
  if (v === 'P3Y') return 'Triennial';
  // pass-through with title-case for already-canonical values
  const lower = raw.trim().toLowerCase();
  if (lower === 'monthly') return 'Monthly';
  if (lower === 'annual') return 'Annual';
  if (lower === 'triennial') return 'Triennial';
  return raw.trim();
}

function normalizeBilling(raw: string): string {
  const lower = raw.trim().toLowerCase();
  if (lower === 'monthly') return 'Monthly';
  if (lower === 'annual') return 'Annual';
  if (lower === 'triennial') return 'Triennial';
  return raw.trim();
}

function normalizeSegment(raw: string): string {
  const lower = raw.trim().toLowerCase();
  if (lower === 'charity') return 'Nonprofit';
  if (lower === 'commercial') return 'Commercial';
  if (lower === 'education') return 'Education';
  if (lower === 'government') return 'Government';
  if (lower === 'nonprofit') return 'Nonprofit';
  return raw.trim();
}

export function PriceListUploadModal({ open, onClose, onUploaded }: Props) {
  const { user } = useAuth();
  const [region, setRegion] = useState<string>('India');
  const regionDef = findRegion(region)!;
  const [market, setMarket] = useState<string>(regionDef.market);
  const [currency, setCurrency] = useState<Currency>(regionDef.currency);
  const [month, setMonth] = useState<string>(getCurrentMonth());
  const [filename, setFilename] = useState<string>('');
  const [rows, setRows] = useState<ParsedRow[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const reset = () => {
    setRows([]); setErrors([]); setFilename('');
  };

  const handleRegionChange = (r: string) => {
    setRegion(r);
    const def = findRegion(r);
    if (def) { setMarket(def.market); setCurrency(def.currency); }
  };

  const handleFile = (file: File) => {
    setFilename(file.name);
    setRows([]);
    setErrors([]);
    Papa.parse<Record<string, any>>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const parsed: ParsedRow[] = [];
        const errs: string[] = [];
        let skipped = 0;
        result.data.forEach((raw, idx) => {
          const lineNo = idx + 2;
          const product_name = pick(raw, 'Product Name', 'Product', 'ProductName', 'SkuTitle');
          const rawBilling = pick(raw, 'Billing', 'Billing Frequency', 'BillingFrequency', 'BillingPlan');
          // Silently skip rows with BillingPlan = "None" (Microsoft NCE exports include these)
          if (rawBilling.trim().toLowerCase() === 'none') { skipped++; return; }
          const commitment_term = normalizeCommitment(pick(raw, 'Commitment', 'Commitment Term', 'CommitmentTerm', 'TermDuration')) as CommitmentTerm;
          const billing_frequency = normalizeBilling(rawBilling) as BillingFrequency;
          const customer_segment = normalizeSegment(pick(raw, 'Segment', 'Customer Segment') || 'Commercial') as CustomerSegment;
          const erpStr = pick(raw, 'ERP Price', 'ERP', 'List Price');
          const costStr = pick(raw, 'Partner Cost', 'Partner Price', 'Cost', 'UnitPrice');
          const product_sku = pick(raw, 'SKU', 'Product SKU', 'ProductSKU', 'SkuId') || null;

          if (!product_name) { errs.push(`Line ${lineNo}: missing Product Name`); return; }
          if (!['Monthly','Annual','Triennial'].includes(commitment_term)) { errs.push(`Line ${lineNo}: invalid Commitment "${commitment_term}"`); return; }
          if (!['Monthly','Annual','Triennial'].includes(billing_frequency)) { errs.push(`Line ${lineNo}: invalid Billing "${billing_frequency}"`); return; }
          if (!isValidNCECombination(commitment_term, billing_frequency)) { errs.push(`Line ${lineNo}: invalid NCE combo ${commitment_term}/${billing_frequency}`); return; }
          if (!SEGMENTS.includes(customer_segment)) { errs.push(`Line ${lineNo}: invalid Segment "${customer_segment}"`); return; }
          // Allow 0 as a valid price; only reject non-numeric or negative values
          const erp = erpStr === '' ? 0 : parseFloat(erpStr);
          const cost = costStr === '' ? 0 : parseFloat(costStr);
          if (!isFinite(erp) || erp < 0) { errs.push(`Line ${lineNo}: invalid ERP Price`); return; }
          if (!isFinite(cost) || cost < 0) { errs.push(`Line ${lineNo}: invalid Partner Cost`); return; }

          parsed.push({ product_name, product_sku, commitment_term, billing_frequency, customer_segment, erp_price: erp, partner_cost: cost });
        });
        if (skipped > 0) console.info(`[PriceList] Skipped ${skipped} row(s) with BillingPlan=None`);
        setRows(parsed);
        setErrors(errs);
      },
    });
  };

  const handleSave = async () => {
    if (!user || rows.length === 0) return;
    setSaving(true);
    try {
      // Check for existing list
      const { data: existing } = await supabase
        .from('partner_price_lists')
        .select('id')
        .eq('user_id', user.id)
        .eq('market', market)
        .eq('currency', currency)
        .eq('price_list_month', month)
        .maybeSingle();

      let priceListId: string;

      if (existing) {
        if (!confirm(`A price list already exists for ${market}/${currency}/${month}. Replace it? (Saved quotes are unaffected.)`)) {
          setSaving(false);
          return;
        }
        // Delete old items, update header
        await supabase.from('partner_price_list_items').delete().eq('price_list_id', existing.id);
        await supabase.from('partner_price_lists').update({
          name: buildPriceListName(market, currency, month),
          region, source_filename: filename, row_count: rows.length, uploaded_at: new Date().toISOString(),
        }).eq('id', existing.id);
        priceListId = existing.id;
      } else {
        const { data: created, error } = await supabase.from('partner_price_lists').insert({
          user_id: user.id,
          name: buildPriceListName(market, currency, month),
          region, market, currency, price_list_month: month,
          source_filename: filename, row_count: rows.length,
        }).select().single();
        if (error) throw error;
        priceListId = created.id;
      }

      // Bulk insert items in batches of 500
      for (let i = 0; i < rows.length; i += 500) {
        const batch = rows.slice(i, i + 500).map(r => ({ ...r, price_list_id: priceListId }));
        const { error } = await supabase.from('partner_price_list_items').insert(batch);
        if (error) throw error;
      }

      onUploaded();
      reset();
      onClose();
    } catch (err: any) {
      alert('Failed to save: ' + (err.message || 'Unknown error'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) { reset(); onClose(); } }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Upload Partner Price List</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Region</Label>
              <Select value={region} onValueChange={handleRegionChange}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REGIONS.map(r => <SelectItem key={r.region} value={r.region}>{r.region}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Market</Label>
              <Input value={market} onChange={e => setMarket(e.target.value.toUpperCase().slice(0, 4))} maxLength={4} />
            </div>
            <div className="space-y-1.5">
              <Label>Currency</Label>
              <Select value={currency} onValueChange={v => setCurrency(v as Currency)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Price List Month</Label>
              <Input type="month" value={month} onChange={e => setMonth(e.target.value)} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>CSV File</Label>
            <Input
              type="file"
              accept=".csv,text/csv"
              onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
            />
            <p className="text-xs text-muted-foreground">
              Expected columns: Product Name | Commitment | Billing | Segment | ERP Price | Partner Cost. Microsoft Partner Center NCE exports (SkuTitle, TermDuration, BillingPlan, UnitPrice, Charity segment) are auto-mapped.
            </p>
          </div>

          {filename && (
            <div className="rounded-md border border-border p-3">
              <p className="text-sm font-medium text-foreground">{filename}</p>
              <p className="text-xs text-muted-foreground">
                {rows.length} valid rows{errors.length > 0 && ` • ${errors.length} errors`}
              </p>

              {rows.length > 0 && (
                <div className="mt-2 max-h-40 overflow-y-auto rounded border border-border">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="p-1.5 text-left">Product</th>
                        <th className="p-1.5">Comm</th>
                        <th className="p-1.5">Bill</th>
                        <th className="p-1.5">Seg</th>
                        <th className="p-1.5 text-right">ERP</th>
                        <th className="p-1.5 text-right">Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.slice(0, 10).map((r, i) => (
                        <tr key={i} className="border-t border-border">
                          <td className="p-1.5 truncate max-w-[180px]">{r.product_name}</td>
                          <td className="p-1.5 text-center">{r.commitment_term}</td>
                          <td className="p-1.5 text-center">{r.billing_frequency}</td>
                          <td className="p-1.5 text-center">{r.customer_segment}</td>
                          <td className="p-1.5 text-right">{r.erp_price}</td>
                          <td className="p-1.5 text-right">{r.partner_cost}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {errors.length > 0 && (
                <div className="mt-2 max-h-32 overflow-y-auto rounded bg-destructive/10 p-2 text-xs text-destructive">
                  <div className="flex items-center gap-1 font-medium"><AlertTriangle className="h-3 w-3" /> Validation errors:</div>
                  <ul className="mt-1 list-disc pl-4">
                    {errors.slice(0, 20).map((e, i) => <li key={i}>{e}</li>)}
                    {errors.length > 20 && <li>... and {errors.length - 20} more</li>}
                  </ul>
                </div>
              )}

              {rows.length > 0 && errors.length === 0 && (
                <div className="mt-2 flex items-center gap-1 text-xs text-success">
                  <CheckCircle2 className="h-3 w-3" /> All rows valid.
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => { reset(); onClose(); }}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || rows.length === 0}>
            <Upload className="h-4 w-4" /> {saving ? 'Saving...' : `Save ${rows.length} rows`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
