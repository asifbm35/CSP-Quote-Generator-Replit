import type { Currency } from '@/lib/pricing';

export interface RegionDef {
  region: string;
  market: string;
  currency: Currency;
}

export const REGIONS: RegionDef[] = [
  { region: 'India',        market: 'IN', currency: 'INR' },
  { region: 'United States', market: 'US', currency: 'USD' },
  { region: 'United Kingdom', market: 'GB', currency: 'GBP' },
  { region: 'European Union', market: 'EU', currency: 'EUR' },
  { region: 'UAE',          market: 'AE', currency: 'AED' },
  { region: 'Saudi Arabia', market: 'SA', currency: 'SAR' },
  { region: 'Australia',    market: 'AU', currency: 'AUD' },
  { region: 'Singapore',    market: 'SG', currency: 'SGD' },
  { region: 'Japan',        market: 'JP', currency: 'JPY' },
  { region: 'China',        market: 'CN', currency: 'CNY' },
  { region: 'Canada',       market: 'CA', currency: 'CAD' },
];

export function findRegion(region: string): RegionDef | undefined {
  return REGIONS.find(r => r.region === region);
}

export function buildPriceListName(market: string, currency: string, month: string): string {
  return `${market} / ${currency} / ${month}`;
}
