// CSP Pricing Logic
// Profit margin is the PRIMARY input; discount is always DERIVED.
// All math uses full precision; round2() applied ONLY at UI render or DB write.

export type Currency = 'INR' | 'USD' | 'AUD' | 'EUR' | 'GBP' | 'AED' | 'SAR' | 'JPY' | 'CNY' | 'SGD' | 'CAD';
export type CommitmentTerm = 'Monthly' | 'Annual' | 'Triennial';
export type BillingFrequency = 'Monthly' | 'Annual' | 'Triennial';
export type MarginStrategy = 'uniform' | 'per_product';
export type CustomerSegment = 'Commercial' | 'Education' | 'Government' | 'Nonprofit';

export const CURRENCIES: Currency[] = ['INR', 'USD', 'AUD', 'EUR', 'GBP', 'AED', 'SAR', 'JPY', 'CNY', 'SGD', 'CAD'];

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  INR: '₹',
  USD: '$',
  AUD: 'A$',
  EUR: '€',
  GBP: '£',
  AED: 'د.إ',
  SAR: '﷼',
  JPY: '¥',
  CNY: '¥',
  SGD: 'S$',
  CAD: 'C$',
};

export const SEGMENTS: CustomerSegment[] = ['Commercial', 'Education', 'Government', 'Nonprofit'];

// Valid NCE commitment + billing combinations
export const VALID_NCE_COMBINATIONS: Array<{ commitment: CommitmentTerm; billing: BillingFrequency[] }> = [
  { commitment: 'Monthly', billing: ['Monthly'] },
  { commitment: 'Annual', billing: ['Monthly', 'Annual'] },
  { commitment: 'Triennial', billing: ['Monthly', 'Annual', 'Triennial'] },
];

export function isValidNCECombination(commitment: CommitmentTerm, billing: BillingFrequency): boolean {
  const rule = VALID_NCE_COMBINATIONS.find(r => r.commitment === commitment);
  return rule ? rule.billing.includes(billing) : false;
}

export function getNCEValidationMessage(commitment: CommitmentTerm, billing: BillingFrequency): string | null {
  if (isValidNCECombination(commitment, billing)) return null;
  return `Invalid NCE combination: ${commitment} commitment cannot have ${billing} billing. ` +
    `${commitment} commitment supports: ${VALID_NCE_COMBINATIONS.find(r => r.commitment === commitment)?.billing.join(', ') || 'none'}.`;
}

// Round only at UI/DB boundaries
export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Period conversion table.
 * - divisor: divides commitment-period unit price to get billing-period unit price.
 * - multiplier: number of billing periods inside one commitment (for total).
 */
function getPeriodFactors(commitment: CommitmentTerm, billing: BillingFrequency): { divisor: number; multiplier: number } {
  if (commitment === 'Monthly' && billing === 'Monthly') return { divisor: 1, multiplier: 1 };
  if (commitment === 'Annual' && billing === 'Monthly') return { divisor: 12, multiplier: 12 };
  if (commitment === 'Annual' && billing === 'Annual') return { divisor: 1, multiplier: 1 };
  if (commitment === 'Triennial' && billing === 'Monthly') return { divisor: 36, multiplier: 36 };
  if (commitment === 'Triennial' && billing === 'Annual') return { divisor: 3, multiplier: 3 };
  if (commitment === 'Triennial' && billing === 'Triennial') return { divisor: 1, multiplier: 1 };
  // fallback (invalid combo will be caught by NCE validator)
  return { divisor: 1, multiplier: 1 };
}

export interface PricingInput {
  /** ERP price at the COMMITMENT period (full precision). */
  erpPrice: number;
  /** Partner cost at the COMMITMENT period (full precision). */
  partnerCost: number;
  /** Profit margin percentage, e.g. 10 for 10%. */
  targetMargin: number;
  quantity: number;
  commitmentTerm: CommitmentTerm;
  billingFrequency: BillingFrequency;
}

export interface PricingResult {
  /** Customer unit price at the BILLING period (rounded to 2 dp). */
  customerUnitPrice: number;
  /** Total price across the full commitment (rounded to 2 dp). */
  totalPrice: number;
  /** Discount derived from ERP at commitment period (rounded to 2 dp). */
  derivedDiscount: number;
  isValid: boolean;
  error?: string;
}

export function calculatePricing(input: PricingInput): PricingResult {
  const { erpPrice, partnerCost, targetMargin, quantity, commitmentTerm, billingFrequency } = input;

  if (partnerCost <= 0) {
    return { customerUnitPrice: 0, totalPrice: 0, derivedDiscount: 0, isValid: false, error: 'Partner cost must be greater than 0' };
  }
  if (erpPrice <= 0) {
    return { customerUnitPrice: 0, totalPrice: 0, derivedDiscount: 0, isValid: false, error: 'ERP price must be greater than 0' };
  }
  if (targetMargin < 0 || targetMargin >= 100) {
    return { customerUnitPrice: 0, totalPrice: 0, derivedDiscount: 0, isValid: false, error: 'Margin must be between 0% and 100%' };
  }
  if (!isValidNCECombination(commitmentTerm, billingFrequency)) {
    return { customerUnitPrice: 0, totalPrice: 0, derivedDiscount: 0, isValid: false, error: getNCEValidationMessage(commitmentTerm, billingFrequency)! };
  }

  // 1. Customer price at COMMITMENT period, then ROUND at the commitment boundary (Excel parity).
  const unitAtCommitmentRaw = partnerCost / (1 - targetMargin / 100);
  const unitAtCommitment = round2(unitAtCommitmentRaw);

  // 2. Derived discount from ERP using ROUNDED commitment price (matches Excel reference).
  const derivedDiscount = erpPrice > 0 ? Math.max(0, ((erpPrice - unitAtCommitment) / erpPrice) * 100) : 0;

  // 3. Convert ROUNDED commitment price to BILLING period, then round for display.
  const { divisor, multiplier } = getPeriodFactors(commitmentTerm, billingFrequency);
  void multiplier;
  const unitAtBilling = round2(unitAtCommitment / divisor);

  // 4. Total = rounded billing unit * qty, rounded again.
  const total = round2(unitAtBilling * quantity);

  return {
    customerUnitPrice: unitAtBilling,
    totalPrice: total,
    derivedDiscount,
    isValid: true,
  };
}

export function isLossMaking(partnerCost: number, customerUnitPriceAtCommitment: number): boolean {
  return customerUnitPriceAtCommitment < partnerCost;
}

export function formatCurrency(amount: number, currency: Currency): string {
  // v2: enforce 2-decimal formatting for all currencies. Currency-specific precision deferred.
  const symbol = CURRENCY_SYMBOLS[currency];
  const formatted = amount.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `${symbol}${formatted}`;
}

export function getBillingLabel(billing: BillingFrequency): string {
  switch (billing) {
    case 'Monthly': return '/month';
    case 'Annual': return '/year';
    case 'Triennial': return '/3 years';
  }
}
