import { supabase } from '@/integrations/supabase/client';

function sanitizeCustomer(name: string): string {
  return (name || 'CUST')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 10) || 'CUST';
}

function yymmdd(d: Date): string {
  const yy = String(d.getFullYear()).slice(-2);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

/**
 * Generate a unique quote number in the format:
 *   DBIZ-Q-{REGION}-{CUSTOMER}-{YYMMDD}-{SEQ}
 *
 * SEQ is the next zero-padded sequence among existing quotes that share the
 * same region+customer+date prefix, ensuring uniqueness across versions.
 */
export async function generateQuoteNumber(opts: {
  region?: string;
  market?: string;
  customerName: string;
  userId: string;
}): Promise<string> {
  const regionCode = (opts.market || opts.region || 'XX')
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 4) || 'XX';
  const customer = sanitizeCustomer(opts.customerName);
  const date = yymmdd(new Date());
  const prefix = `DBIZ-Q-${regionCode}-${customer}-${date}-`;

  const { data } = await supabase
    .from('quotes')
    .select('quote_number')
    .eq('user_id', opts.userId)
    .like('quote_number', `${prefix}%`);

  let maxSeq = 0;
  (data || []).forEach((r: any) => {
    const tail = (r.quote_number || '').slice(prefix.length);
    const n = parseInt(tail, 10);
    if (!isNaN(n) && n > maxSeq) maxSeq = n;
  });
  const seq = String(maxSeq + 1).padStart(3, '0');
  return `${prefix}${seq}`;
}
