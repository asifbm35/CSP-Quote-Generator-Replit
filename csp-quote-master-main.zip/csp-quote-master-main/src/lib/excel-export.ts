import ExcelJS from 'exceljs';
import type { QuoteItemRow } from '@/components/QuoteItemsEditor';
import type { QuoteHeaderData } from '@/components/QuoteHeaderForm';
import { CURRENCY_SYMBOLS, type BillingFrequency, type CommitmentTerm } from '@/lib/pricing';

function billingDivisor(commitment: CommitmentTerm, billing: BillingFrequency): number {
  if (commitment === 'Annual' && billing === 'Monthly') return 12;
  if (commitment === 'Triennial' && billing === 'Monthly') return 36;
  if (commitment === 'Triennial' && billing === 'Annual') return 3;
  return 1;
}

const BRAND_BLACK = 'FF000000';
const BRAND_BLUE = 'FF1E40AF';
const BRAND_ORANGE = 'FFFF6A13';
const HEADER_BG = 'FF1E40AF';
const EDITABLE_BG = 'FFFFF4CC';
const FORMULA_BG = 'FFF3F4F6';

export async function exportQuoteToExcel(
  header: QuoteHeaderData,
  items: QuoteItemRow[],
  fileName: string,
  quoteNumber?: string,
) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DBiz.ai CSP Quote Generator';
  wb.created = new Date();

  const ws = wb.addWorksheet('Quote', {
    views: [{ showGridLines: false }],
    pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 },
  });

  const symbol = CURRENCY_SYMBOLS[header.currency] || '';
  const currencyFmt = `"${symbol}"#,##0.00;[Red]("${symbol}"#,##0.00);-`;
  const pctFmt = '0.00%';

  // Column widths (A..L = 12 cols)  — added Profit column at L
  ws.columns = [
    { width: 6 },   // A  #
    { width: 38 },  // B  Product
    { width: 10 },  // C  Qty (editable)
    { width: 14 },  // D  Commitment
    { width: 14 },  // E  Billing
    { width: 14 },  // F  ERP
    { width: 14 },  // G  Partner Cost
    { width: 12 },  // H  Margin % (editable)
    { width: 16 },  // I  Customer Unit Price
    { width: 12 },  // J  Discount %
    { width: 16 },  // K  Total Price
    { width: 16 },  // L  Profit
  ];

  // ---------- BRAND HEADER BAND ----------
  ws.mergeCells('A1:L3');
  const brand = ws.getCell('A1');
  brand.value = {
    richText: [
      { text: 'DBiz.AI   ', font: { bold: true, size: 22, color: { argb: 'FFFFFFFF' } } },
      { text: 'IMPACT', font: { bold: true, size: 14, color: { argb: 'FFFFFFFF' } } },
      { text: 'FUL', font: { bold: true, size: 14, color: { argb: BRAND_ORANGE } } },
      { text: '  EXPERIENCE  ', font: { bold: true, size: 11, color: { argb: 'FFFFFFFF' } } },
      { text: '@', font: { bold: true, size: 11, color: { argb: BRAND_ORANGE } } },
      { text: ' SCALE', font: { bold: true, size: 11, color: { argb: 'FFFFFFFF' } } },
    ],
  };
  brand.alignment = { vertical: 'middle', horizontal: 'left', indent: 2 };
  brand.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: BRAND_BLACK } };
  ws.getRow(1).height = 28;
  ws.getRow(2).height = 22;
  ws.getRow(3).height = 6;

  // ---------- QUOTE METADATA ----------
  const meta: Array<[string, string]> = [
    ['Reseller Name', 'DBiz.AI'],
    ['Contact', 'Abhi Chandra (abhi.chandra@dbizsolution.com)'],
    ['Organization', header.customerName || ''],
    ['Customer Segment', header.customerSegment || ''],
    ['Currency', header.currency || ''],
    ['Valid Till', header.validTill || ''],
  ];
  if (quoteNumber) meta.push(['Quote #', quoteNumber]);

  let row = 5;
  meta.forEach(([k, v]) => {
    const lc = ws.getCell(`B${row}`);
    const rc = ws.getCell(`D${row}`);
    ws.mergeCells(`B${row}:C${row}`);
    ws.mergeCells(`D${row}:G${row}`);
    lc.value = k;
    lc.font = { bold: true, color: { argb: BRAND_BLUE } };
    rc.value = v;
    rc.font = k === 'Quote #'
      ? { color: { argb: BRAND_ORANGE }, bold: true, name: 'Consolas' }
      : { color: { argb: BRAND_BLACK } };
    rc.alignment = { vertical: 'middle' };
    row += 1;
  });

  ws.getCell(`I5`).value = 'CSP Quote';
  ws.mergeCells('I5:L6');
  ws.getCell('I5').font = { bold: true, size: 18, color: { argb: BRAND_BLUE } };
  ws.getCell('I5').alignment = { vertical: 'middle', horizontal: 'right' };

  ws.getCell('I7').value = 'Editable: Margin % and Quantity';
  ws.mergeCells('I7:L7');
  ws.getCell('I7').font = { italic: true, size: 9, color: { argb: 'FF6B7280' } };
  ws.getCell('I7').alignment = { horizontal: 'right' };

  row = 13;

  // ---------- TABLE HEADERS ----------
  const headers = [
    '#', 'Product Name', 'Qty', 'Commitment', 'Billing',
    'ERP', 'Partner Cost', 'Margin %', 'Customer Unit Price', 'Discount %', 'Total Price', 'Profit',
  ];
  headers.forEach((h, i) => {
    const cell = ws.getCell(row, i + 1);
    cell.value = h;
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_BG } };
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.border = {
      top: { style: 'thin', color: { argb: BRAND_BLUE } },
      bottom: { style: 'medium', color: { argb: BRAND_BLUE } },
      left: { style: 'thin', color: { argb: BRAND_BLUE } },
      right: { style: 'thin', color: { argb: BRAND_BLUE } },
    };
  });
  ws.getRow(row).height = 30;

  const headerRow = row;
  const firstDataRow = row + 1;

  // ---------- LINE ITEMS ----------
  items.forEach((it, idx) => {
    const r = firstDataRow + idx;
    const divisor = billingDivisor(it.commitmentTerm, it.billingFrequency);
    const marginFraction = (it.targetMargin || 0) / 100;

    ws.getCell(r, 1).value = idx + 1;
    ws.getCell(r, 2).value = it.productName;
    ws.getCell(r, 3).value = it.quantity;        // EDITABLE Qty
    ws.getCell(r, 4).value = it.commitmentTerm;
    ws.getCell(r, 5).value = it.billingFrequency;
    ws.getCell(r, 6).value = it.erpPrice;        // ERP (commitment level, fixed)
    ws.getCell(r, 7).value = it.partnerCost;     // Partner cost (commitment level, fixed)
    ws.getCell(r, 8).value = marginFraction;     // EDITABLE Margin

    // Customer Unit Price (billing) = ROUND(ROUND(PartnerCost/(1-Margin),2)/divisor,2)
    ws.getCell(r, 9).value = {
      formula: `ROUND(ROUND(G${r}/(1-H${r}),2)/${divisor},2)`,
    };
    // Discount % = (ERP - CommitmentPrice) / ERP, where CommitmentPrice = I*divisor
    ws.getCell(r, 10).value = {
      formula: `IFERROR(ROUND((F${r}-(I${r}*${divisor}))/F${r},4),0)`,
    };
    // Total Price = ROUND(I * Qty, 2)
    ws.getCell(r, 11).value = {
      formula: `ROUND(I${r}*C${r},2)`,
    };
    // Profit = Total - (PartnerCost * Qty / divisor)   — billing-frequency-normalized cost
    ws.getCell(r, 12).value = {
      formula: `ROUND(K${r}-(G${r}*C${r}/${divisor}),2)`,
    };

    // Formatting
    [6, 7, 9, 11, 12].forEach(c => { ws.getCell(r, c).numFmt = currencyFmt; });
    ws.getCell(r, 8).numFmt = pctFmt;
    ws.getCell(r, 10).numFmt = pctFmt;
    ws.getCell(r, 1).alignment = { horizontal: 'center' };
    ws.getCell(r, 3).alignment = { horizontal: 'center' };
    ws.getCell(r, 4).alignment = { horizontal: 'center' };
    ws.getCell(r, 5).alignment = { horizontal: 'center' };

    // Editable highlight (Qty + Margin)
    [3, 8].forEach(c => {
      ws.getCell(r, c).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: EDITABLE_BG } };
      ws.getCell(r, c).font = { bold: true, color: { argb: BRAND_BLACK } };
    });
    // Formula cell shading
    [9, 10, 11, 12].forEach(c => {
      ws.getCell(r, c).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: FORMULA_BG } };
    });

    // Borders + lock state — unlock Qty (3) and Margin (8) only
    for (let c = 1; c <= 12; c++) {
      const cell = ws.getCell(r, c);
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFD1D5DB' } },
        bottom: { style: 'thin', color: { argb: 'FFD1D5DB' } },
        left: { style: 'thin', color: { argb: 'FFD1D5DB' } },
        right: { style: 'thin', color: { argb: 'FFD1D5DB' } },
      };
      cell.protection = { locked: !(c === 3 || c === 8) };
    }
    ws.getRow(r).height = 20;
  });

  const lastDataRow = firstDataRow + items.length - 1;
  const totalRow = lastDataRow + 1;

  // ---------- GRAND TOTAL ----------
  ws.mergeCells(`A${totalRow}:J${totalRow}`);
  const totLabel = ws.getCell(`A${totalRow}`);
  totLabel.value = 'Grand Total';
  totLabel.font = { bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
  totLabel.alignment = { horizontal: 'right', vertical: 'middle', indent: 1 };
  totLabel.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: BRAND_BLUE } };

  const totCell = ws.getCell(`K${totalRow}`);
  totCell.value = items.length > 0
    ? { formula: `SUM(K${firstDataRow}:K${lastDataRow})` }
    : 0;
  totCell.numFmt = currencyFmt;
  totCell.font = { bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
  totCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: BRAND_BLUE } };
  totCell.alignment = { horizontal: 'right', vertical: 'middle' };

  const profitCell = ws.getCell(`L${totalRow}`);
  profitCell.value = items.length > 0
    ? { formula: `SUM(L${firstDataRow}:L${lastDataRow})` }
    : 0;
  profitCell.numFmt = currencyFmt;
  profitCell.font = { bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
  profitCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: BRAND_BLUE } };
  profitCell.alignment = { horizontal: 'right', vertical: 'middle' };

  ws.getRow(totalRow).height = 26;

  // ---------- OUTER FRAMING for table ----------
  const tableTopBorder = { style: 'medium' as const, color: { argb: BRAND_BLUE } };
  for (let c = 1; c <= 12; c++) {
    const cell = ws.getCell(headerRow, c);
    cell.border = { ...cell.border, top: tableTopBorder };
  }

  // ---------- FOOTER ----------
  const footerRow = totalRow + 3;
  ws.mergeCells(`A${footerRow}:L${footerRow}`);
  ws.getCell(`A${footerRow}`).value =
    '• All prices are exclusive of applicable taxes.   • Edit the highlighted Margin % and Quantity cells — Customer Unit Price, Discount %, Total Price and Profit recalculate automatically.';
  ws.getCell(`A${footerRow}`).font = { italic: true, size: 9, color: { argb: 'FF6B7280' } };

  ws.mergeCells(`A${footerRow + 1}:L${footerRow + 1}`);
  ws.getCell(`A${footerRow + 1}`).value = 'Generated by DBiz.ai CSP Quote Generator';
  ws.getCell(`A${footerRow + 1}`).font = { size: 9, color: { argb: 'FF9CA3AF' } };

  // ---------- LEGEND ----------
  const legendRow = footerRow + 3;
  ws.getCell(`B${legendRow}`).value = 'Editable';
  ws.getCell(`B${legendRow}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: EDITABLE_BG } };
  ws.getCell(`B${legendRow}`).border = {
    top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' },
  };
  ws.getCell(`C${legendRow}`).value = 'Formula (auto)';
  ws.getCell(`C${legendRow}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: FORMULA_BG } };
  ws.getCell(`C${legendRow}`).border = {
    top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' },
  };

  // ---------- SHEET PROTECTION (allow Qty + Margin edits) ----------
  await ws.protect('', {
    selectLockedCells: true,
    selectUnlockedCells: true,
    formatCells: false,
    formatColumns: false,
    formatRows: false,
  });

  // ---------- SAVE ----------
  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
