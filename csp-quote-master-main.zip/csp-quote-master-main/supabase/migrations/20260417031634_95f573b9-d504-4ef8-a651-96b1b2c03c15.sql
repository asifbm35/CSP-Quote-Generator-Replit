-- 1. partner_price_lists
CREATE TABLE public.partner_price_lists (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  region TEXT NOT NULL,
  market TEXT NOT NULL,
  currency TEXT NOT NULL,
  price_list_month TEXT NOT NULL,
  source_filename TEXT,
  row_count INTEGER NOT NULL DEFAULT 0,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, market, currency, price_list_month)
);

ALTER TABLE public.partner_price_lists ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own price lists"
  ON public.partner_price_lists FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own price lists"
  ON public.partner_price_lists FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own price lists"
  ON public.partner_price_lists FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own price lists"
  ON public.partner_price_lists FOR DELETE
  USING (auth.uid() = user_id);

CREATE TRIGGER update_partner_price_lists_updated_at
  BEFORE UPDATE ON public.partner_price_lists
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2. partner_price_list_items
CREATE TABLE public.partner_price_list_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  price_list_id UUID NOT NULL REFERENCES public.partner_price_lists(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  product_sku TEXT,
  commitment_term TEXT NOT NULL,
  billing_frequency TEXT NOT NULL,
  customer_segment TEXT NOT NULL DEFAULT 'Commercial',
  erp_price NUMERIC NOT NULL DEFAULT 0,
  partner_cost NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_pli_lookup
  ON public.partner_price_list_items
  (price_list_id, product_name, commitment_term, billing_frequency, customer_segment);

CREATE INDEX idx_pli_price_list_id
  ON public.partner_price_list_items (price_list_id);

ALTER TABLE public.partner_price_list_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own price list items"
  ON public.partner_price_list_items FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM public.partner_price_lists pl
    WHERE pl.id = partner_price_list_items.price_list_id
      AND pl.user_id = auth.uid()
  ));

CREATE POLICY "Users can create own price list items"
  ON public.partner_price_list_items FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.partner_price_lists pl
    WHERE pl.id = partner_price_list_items.price_list_id
      AND pl.user_id = auth.uid()
  ));

CREATE POLICY "Users can update own price list items"
  ON public.partner_price_list_items FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM public.partner_price_lists pl
    WHERE pl.id = partner_price_list_items.price_list_id
      AND pl.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete own price list items"
  ON public.partner_price_list_items FOR DELETE
  USING (EXISTS (
    SELECT 1 FROM public.partner_price_lists pl
    WHERE pl.id = partner_price_list_items.price_list_id
      AND pl.user_id = auth.uid()
  ));

-- 3. Extend quotes
ALTER TABLE public.quotes
  ADD COLUMN region TEXT,
  ADD COLUMN market TEXT,
  ADD COLUMN price_list_id UUID REFERENCES public.partner_price_lists(id) ON DELETE SET NULL;

CREATE INDEX idx_quotes_price_list_id ON public.quotes(price_list_id);

-- 4. Extend quote_items
ALTER TABLE public.quote_items
  ADD COLUMN price_list_item_id UUID REFERENCES public.partner_price_list_items(id) ON DELETE SET NULL;

CREATE INDEX idx_quote_items_price_list_item_id ON public.quote_items(price_list_item_id);
